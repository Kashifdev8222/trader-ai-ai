// assets/js/tabs/help.tab.js — Trader AI chat embed
window.CP_tabs = window.CP_tabs || {};

const HELP_CHAT_URL = 'https://traderai.ai/chat.html';

window.CP_tabs.help = function () {
  const section = document.querySelector('section.view[data-view="help"]');
  if (!section || section.dataset.cpEmbedReady === '1') return;

  const url = HELP_CHAT_URL;
  const title = 'Help';

  section.innerHTML = `
    <div class="cp-embed-wrap">
      <div class="cp-embed-toolbar">
        <span class="cp-embed-title">${title}</span>
        <a class="cp-embed-external" href="${url}" target="_blank" rel="noopener noreferrer">Open in new tab</a>
      </div>
      <div class="cp-embed-frame-wrap">
        <iframe class="cp-embed-frame" src="${url}" title="${title}" referrerpolicy="no-referrer-when-downgrade" loading="lazy"></iframe>
      </div>
    </div>`;

  section.dataset.cpEmbedReady = '1';
};
