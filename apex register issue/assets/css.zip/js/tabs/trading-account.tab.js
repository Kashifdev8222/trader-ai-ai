// Trading Account tab — Figma layout; api/accounts/get_accounts.php (session)
window.CP_tabs = window.CP_tabs || {};
window.CP_onViewShow = window.CP_onViewShow || {};

(function () {
  const PAGE_SIZE = 6;

  /* Same SVG paths as Dashboard home Deposit / Withdraw (viewBox 26×26); fill via currentColor */
  const SVG_DEPOSIT = `<svg class="ta-svg-dash" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M23.8834 0.00121754H2.11661C0.950049 0.00121754 0 0.996359 0 2.221V4.75702C0 5.98044 0.948888 6.9768 2.11661 6.9768H3.6278V22.5128C3.6278 24.4365 5.11973 26 6.9529 26H19.046C20.8803 26 22.3711 24.4353 22.3711 22.5128L22.3722 6.97558H23.8834C25.05 6.97558 26 5.98044 26 4.7558V2.21978C26 0.996359 25.0511 0 23.8834 0L23.8834 0.00121754ZM20.5583 1.90354V19.0244H20.2556C17.7558 19.0244 15.7209 21.1574 15.7209 23.7802V24.0977H10.2792V23.7802C10.2792 21.1574 8.2442 19.0244 5.74441 19.0244H5.4417V1.90354H20.5583ZM2.11661 5.07326C1.95222 5.07326 1.8139 4.92821 1.8139 4.7558V2.21978C1.8139 2.04738 1.95221 1.90232 2.11661 1.90232H3.6278V5.07326H2.11661ZM5.4417 22.5116V20.9267H5.74441C7.24429 20.9267 8.46526 22.2072 8.46526 23.7802V24.0977H6.95406C6.1208 24.0977 5.44287 23.3867 5.44287 22.5128L5.4417 22.5116ZM19.046 24.0965H17.5348V23.779C17.5348 22.206 18.7557 20.9255 20.2556 20.9255H20.5583V22.5104C20.5583 23.3843 19.8804 24.0952 19.0471 24.0952L19.046 24.0965ZM24.185 4.7558C24.185 4.9282 24.0467 5.07326 23.8823 5.07326H22.3711V1.90232H23.8823C24.0466 1.90232 24.185 2.04737 24.185 2.21978V4.7558ZM9.93902 10.6874C9.58416 10.3152 9.58416 9.71364 9.93902 9.34268L11.5024 7.70312C12.3265 6.83755 13.6711 6.83755 14.4952 7.70312L16.0585 9.34268C16.4134 9.71483 16.4134 10.3164 16.0585 10.6874C15.8817 10.8729 15.6504 10.9656 15.4169 10.9656C15.1845 10.9656 14.9532 10.8729 14.7752 10.6874L13.9045 9.77427V15.9841C13.9045 16.5096 13.4987 16.9352 12.9976 16.9352C12.4965 16.9352 12.0906 16.5096 12.0906 15.9841V9.77427L11.22 10.6874C10.8651 11.0595 10.2915 11.0595 9.93774 10.6874H9.93902Z" fill="currentColor"/></svg>`;

  const SVG_WITHDRAW = `<svg class="ta-svg-dash" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M3.93047 2C2.76165 2 1.81387 3.04499 1.81387 4.33376C1.81387 5.62249 2.76163 6.66627 3.93047 6.66627H4.23318V4.33376C4.23318 3.78125 4.63903 3.33376 5.14013 3.33376C5.6401 3.33376 6.04708 3.78125 6.04708 4.33376V15.6662C6.04708 16.955 6.9937 18 8.16255 18C8.66365 18 9.0695 18.4475 9.0695 19C9.0695 19.5525 8.66365 20 8.16255 20C5.99266 20 4.23321 18.06 4.23321 15.6662V8.66623H3.9305C1.75948 8.66623 0 6.72624 0 4.33376C0 1.94 1.75948 0 3.9305 0H22.0695C24.2405 0 26 1.94 26 4.33376C26 6.72627 24.2405 8.66623 22.0695 8.66623H21.7668V15.6662C21.7668 18.06 20.0073 20 17.8375 20C17.3364 20 16.9305 19.5525 16.9305 19C16.9305 18.4475 17.3364 18 17.8375 18C19.0063 18 19.9529 16.955 19.9529 15.6662V4.33376C19.9529 3.78125 20.3599 3.33376 20.8599 3.33376C21.361 3.33376 21.7668 3.78125 21.7668 4.33376V6.66627H22.0695C23.2383 6.66627 24.1861 5.62252 24.1861 4.33376C24.1861 3.04502 23.2384 2 22.0695 2H3.93047Z" fill="currentColor"/><path d="M13.6409 25.7075L15.4548 23.7075C15.8085 23.3163 15.8085 22.6838 15.4548 22.2925C15.0999 21.9025 14.5263 21.9025 14.1714 22.2925L13.9061 22.5863V19.6663C13.9061 19.115 13.5003 18.6663 12.9992 18.6663C12.4981 18.6663 12.0922 19.115 12.0922 19.6663V22.5863L11.827 22.2925C11.4721 21.9025 10.8985 21.9025 10.5436 22.2925C10.1899 22.6838 10.1899 23.3163 10.5436 23.7075L12.3575 25.7075C12.7124 26.0975 13.286 26.0975 13.6409 25.7075Z" fill="currentColor"/><path fill-rule="evenodd" clip-rule="evenodd" d="M12.9999 6.66626C11.1633 6.66626 9.6748 8.30875 9.6748 10.3338C9.6748 12.3588 11.1633 14 12.9999 14C14.8365 14 16.325 12.3588 16.325 10.3338C16.325 8.30879 14.8365 6.66626 12.9999 6.66626ZM11.4887 10.3338C11.4887 9.41253 12.1655 8.66629 12.9999 8.66629C13.8343 8.66629 14.5111 9.41253 14.5111 10.3338C14.5111 11.2538 13.8343 12 12.9999 12C12.1655 12 11.4887 11.2538 11.4887 10.3338Z" fill="currentColor"/></svg>`;

  const SVG_EDIT = `<svg class="ta-svg-edit" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M11.0179 0.922829L4.90094 7.59796C4.77942 7.72972 4.69815 7.90511 4.6579 8.08135L4.01006 11.9459C3.9698 12.2095 4.05031 12.5166 4.25309 12.7365C4.41487 12.9119 4.61765 13 4.82044 13H4.98221L8.54651 12.2976C8.70828 12.2539 8.87082 12.1658 8.99234 12.0341L15.1496 5.35809C16.2835 4.12864 16.2835 2.15228 15.1496 0.921986C13.9746 -0.307466 12.1518 -0.307446 11.0179 0.922829ZM13.9746 4.085L7.97994 10.5847L5.83284 10.98L6.23765 8.60838L12.1921 2.15228C12.6782 1.62525 13.4885 1.62525 13.9746 2.15228C14.4607 2.72295 14.4607 3.55797 13.9746 4.085Z" fill="currentColor"/><path d="M0.841554 16H15.1576C15.6211 16 16 15.621 16 15.1576L15.9992 8.00039C15.9992 7.53697 15.6203 7.15803 15.1568 7.15803C14.6934 7.15803 14.3145 7.53697 14.3145 8.00039V14.3161H1.68393V1.68472H7.99962C8.46303 1.68472 8.84198 1.30578 8.84198 0.842359C8.84198 0.378941 8.46303 0 7.99962 0L0.841572 0.000789652C0.378941 0.000789652 0 0.37973 0 0.842361V15.1584C0 15.6211 0.378922 16 0.841554 16Z" fill="currentColor"/></svg>`;

  let accounts = [];
  let filterKind = 'real';
  let page = 1;
  let openMenuRow = null;

  function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s == null ? '' : String(s);
    return d.innerHTML;
  }

  function fmtMoney(n) {
    const v = Number(n);
    if (Number.isNaN(v)) return '0.00';
    return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function fmtBalanceCell(acc) {
    const v = fmtMoney(acc.balance);
    const c = (acc.baseCurrency || 'USD').toUpperCase();
    if (c === 'USD') return `$ ${v}`;
    return `${v} ${c}`;
  }

  function fmtCurrencyCol(acc) {
    const c = (acc.baseCurrency || 'USD').toUpperCase();
    if (c === 'USD') return '$ ' + fmtMoney(acc.balance);
    return c;
  }

  function fmtLastSync(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '—';
    return d.toLocaleString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  }

  function taCell(label, valueInnerHtml) {
    return `<td><div class="ta-cell"><span class="ta-cell-label">${label}</span><div class="ta-cell-value">${valueInnerHtml}</div></div></td>`;
  }

  function filteredAccounts() {
    return accounts.filter(acc => {
      const demo = !!acc.isDemoAccount;
      return filterKind === 'demo' ? demo : !demo;
    });
  }

  function setTableEmptyState(empty) {
    const wrap = document.querySelector('.view-ta .ta-table-responsive');
    const table = document.querySelector('.view-ta .ta-table');
    wrap?.classList.toggle('ta-table-wrap--empty', empty);
    table?.classList.toggle('ta-table--empty', empty);
  }

  function closeAllMenus() {
    document.querySelectorAll('.ta-row-dropdown').forEach(el => {
      el.hidden = true;
      el.removeAttribute('style');
    });
    document.querySelectorAll('.ta-kebab[aria-expanded="true"]').forEach(b => b.setAttribute('aria-expanded', 'false'));
    openMenuRow = null;
  }

  function positionTaDropdown(btn, drop) {
    const r = btn.getBoundingClientRect();
    const gap = 8;
    drop.style.position = 'fixed';
    drop.style.zIndex = '1055';
    drop.style.left = 'auto';
    drop.style.right = `${Math.max(8, Math.round(window.innerWidth - r.right))}px`;
    let top = r.bottom + gap;
    drop.style.top = `${Math.round(top)}px`;
    requestAnimationFrame(() => {
      const h = drop.offsetHeight;
      if (top + h > window.innerHeight - 12) {
        top = Math.max(12, r.top - h - gap);
        drop.style.top = `${Math.round(top)}px`;
      }
    });
  }

  function renderPagination(total, cur, pages, el, onPage) {
    if (!el) return;
    if (total === 0) {
      el.innerHTML = '';
      return;
    }
    const p = Math.min(Math.max(1, cur), pages);
    let html = '';
    html += `<button type="button" class="ta-page-btn ta-page-btn--arrow" ${p <= 1 ? 'disabled' : ''} data-tap="${p - 1}" aria-label="Previous">&lt;</button>`;
    for (let i = 1; i <= pages; i++) {
      html += `<button type="button" class="ta-page-btn ${i === p ? 'is-active' : ''}" data-tap="${i}">${i}</button>`;
    }
    html += `<button type="button" class="ta-page-btn ta-page-btn--arrow" ${p >= pages ? 'disabled' : ''} data-tap="${p + 1}" aria-label="Next">&gt;</button>`;
    el.innerHTML = html;
    el.querySelectorAll('.ta-page-btn[data-tap]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.disabled) return;
        const next = parseInt(btn.getAttribute('data-tap'), 10);
        if (!Number.isNaN(next)) onPage(next);
      });
    });
  }

  function renderTable() {
    const tbody = document.getElementById('taTableBody');
    const totalEl = document.getElementById('taTotalBalance');
    const pagEl = document.getElementById('taPagination');
    if (!tbody) return;

    closeAllMenus();

    const list = filteredAccounts().filter(a => !a.isArchived);
    const sum = list.reduce((acc, a) => acc + (Number(a.balance) || 0), 0);
    if (totalEl) totalEl.textContent = '$ ' + fmtMoney(sum);

    const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
    page = Math.min(page, pages);
    const start = (page - 1) * PAGE_SIZE;
    const slice = list.slice(start, start + PAGE_SIZE);

    const pagHandler = np => {
      page = np;
      renderTable();
    };

    if (!slice.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="ta-empty">No accounts in this category.</td></tr>`;
      setTableEmptyState(true);
      renderPagination(list.length, page, pages, pagEl, pagHandler);
      return;
    }

    setTableEmptyState(false);

    tbody.innerHTML = slice
      .map((acc, idx) => {
        const active = !acc.isDisabled && !acc.isArchived;
        const statusInner = active
          ? `<span class="ta-status"><span class="ta-status-dot ta-status-dot--active" aria-hidden="true"></span>Active</span>`
          : `<span class="ta-status"><span class="ta-status-dot ta-status-dot--off" aria-hidden="true"></span>Inactive</span>`;
        const lastIso = acc.lastLoginNew || acc.lastLogin;
        const syncStr = lastIso ? fmtLastSync(lastIso) : '—';
        const menuId = `m${start + idx}`;
        const accId = escapeHtml(acc.id || '');
        const tpPlain = acc.tpNumber != null && acc.tpNumber !== '' ? String(acc.tpNumber) : '—';
        const tpSafe = escapeHtml(tpPlain);
        const nameEsc = escapeHtml(acc.name || '');

        return `
        <tr data-acc-id="${accId}">
          ${taCell('TP Number', tpSafe)}
          ${taCell('Balance', escapeHtml(fmtBalanceCell(acc)))}
          ${taCell('Currency', escapeHtml(fmtCurrencyCol(acc)))}
          ${taCell('Status', statusInner)}
          ${taCell('Last Sync Time', escapeHtml(syncStr))}
          <td class="ta-actions-cell ta-td--actions">
            <button type="button" class="ta-kebab" data-ta-menu="${menuId}" aria-label="Row actions" aria-expanded="false">
              <i class="bi bi-three-dots-vertical fs-5"></i>
            </button>
            <div class="ta-row-dropdown" id="ta-menu-${menuId}" hidden>
              <button type="button" class="ta-drop-deposit" data-act="deposit" data-tp="${tpSafe}" data-id="${accId}">
                ${SVG_DEPOSIT} Deposit
              </button>
              <button type="button" class="ta-drop-link" data-act="withdraw" data-tp="${tpSafe}" data-id="${accId}">
                ${SVG_WITHDRAW} Withdraw
              </button>
              <button type="button" class="ta-drop-link" data-act="edit" data-tp="${tpSafe}" data-id="${accId}" data-name="${nameEsc}">
                ${SVG_EDIT} Edit
              </button>
            </div>
          </td>
        </tr>`;
      })
      .join('');

    renderPagination(list.length, page, pages, pagEl, pagHandler);

    tbody.querySelectorAll('.ta-kebab').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = btn.getAttribute('data-ta-menu');
        const drop = document.getElementById('ta-menu-' + id);
        if (!drop) return;
        const wasOpen = !drop.hidden;
        closeAllMenus();
        if (!wasOpen) {
          drop.hidden = false;
          positionTaDropdown(btn, drop);
          btn.setAttribute('aria-expanded', 'true');
          openMenuRow = id;
        }
      });
    });

    tbody.querySelectorAll('.ta-row-dropdown button[data-act]').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const act = btn.getAttribute('data-act');
        const id = btn.getAttribute('data-id');
        const tp = btn.getAttribute('data-tp');
        closeAllMenus();
        if (act === 'deposit') {
          window.CP_state = window.CP_state || {};
          window.CP_state.preferredTpNumber = tp;
          if (typeof window.CP_showView === 'function') window.CP_showView('deposit');
        }
        if (act === 'withdraw') {
          window.CP_state = window.CP_state || {};
          window.CP_state.preferredTpNumber = tp;
          if (typeof window.CP_showView === 'function') window.CP_showView('withdraw');
        }
        if (act === 'edit') {
          const name = btn.getAttribute('data-name') || '';
          document.getElementById('taEditAccountId').value = id;
          document.getElementById('taEditAccountName').value = name;
          const msg = document.getElementById('taEditMsg');
          if (msg) {
            msg.textContent = '';
            msg.className = 'small mt-2 text-center';
          }
          const modalEl = document.getElementById('taEditNameModal');
          if (modalEl) {
            const m = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
            m.show();
          }
        }
      });
    });
  }

  async function loadAccounts() {
    const tbody = document.getElementById('taTableBody');
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="6" class="ta-empty">Loading…</td></tr>`;
    }
    try {
      const uid = window.CP_USER?.userId || '';
      const url = uid ? `api/accounts/get_accounts.php?userId=${encodeURIComponent(uid)}` : 'api/accounts/get_accounts.php';
      const res = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
      const json = await res.json();
      if (!res.ok || json.status === 'error') {
        throw new Error(json.message || 'Failed to load');
      }
      const raw = json.data;
      accounts = Array.isArray(raw) ? raw : raw?.accounts || [];
      if (window.CP_state) window.CP_state.accounts = accounts;
      renderTable();
    } catch (err) {
      console.error('Trading accounts:', err);
      if (tbody) {
        tbody.innerHTML = `<tr><td colspan="6" class="ta-empty text-danger">Could not load accounts.</td></tr>`;
        setTableEmptyState(true);
      }
    }
  }

  function bindStaticUi() {
    const typeBtn = document.getElementById('taTypeBtn');
    const typeMenu = document.getElementById('taTypeMenu');
    const typeLabel = document.getElementById('taTypeLabel');

    typeBtn?.addEventListener('click', e => {
      e.stopPropagation();
      closeAllMenus();
      const willShow = typeMenu.hidden;
      typeMenu.hidden = !willShow;
      typeBtn.setAttribute('aria-expanded', willShow ? 'true' : 'false');
    });

    document.querySelectorAll('.ta-type-option').forEach(opt => {
      opt.addEventListener('click', () => {
        const kind = opt.getAttribute('data-kind');
        filterKind = kind === 'demo' ? 'demo' : 'real';
        if (typeLabel) typeLabel.textContent = filterKind === 'demo' ? 'Demo Account' : 'Real Account';
        typeMenu.hidden = true;
        typeBtn.setAttribute('aria-expanded', 'false');
        page = 1;
        renderTable();
      });
    });

    document.addEventListener('click', () => {
      if (typeMenu && !typeMenu.hidden) {
        typeMenu.hidden = true;
        typeBtn?.setAttribute('aria-expanded', 'false');
      }
      closeAllMenus();
    });

    typeMenu?.addEventListener('click', e => e.stopPropagation());

    document.getElementById('trading-account-root')?.addEventListener('click', e => {
      if (e.target.closest('.ta-row-dropdown')) e.stopPropagation();
    });

    window.addEventListener('resize', closeAllMenus);
    document.addEventListener('scroll', closeAllMenus, true);

    document.getElementById('taCreateAccount')?.addEventListener('click', () => {
      alert('Create Account: connect your onboarding or CRM flow here.');
    });

    document.getElementById('taEditNameForm')?.addEventListener('submit', async e => {
      e.preventDefault();
      const id = document.getElementById('taEditAccountId').value;
      const name = document.getElementById('taEditAccountName').value.trim();
      const msg = document.getElementById('taEditMsg');
      if (!id || !name) return;
      msg.className = 'small mt-2 text-muted text-center';
      msg.textContent = 'Saving…';
      try {
        const res = await fetch('api/accounts/update_account_name.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ accountId: id, name })
        });
        const data = await res.json();
        if (!res.ok || data.status === 'error') {
          msg.className = 'small mt-2 text-danger text-center';
          msg.textContent = data.message || 'Failed to update';
          return;
        }
        msg.className = 'small mt-2 text-success text-center';
        msg.textContent = 'Updated.';
        bootstrap.Modal.getInstance(document.getElementById('taEditNameModal'))?.hide();
        await loadAccounts();
      } catch {
        msg.className = 'small mt-2 text-danger text-center';
        msg.textContent = 'Network error';
      }
    });
  }

  window.CP_tabs['trading-account'] = async function tradingAccountTabInit() {
    const holder = document.getElementById('trading-account-root');
    if (!holder || holder.dataset.taReady === '1') return;
    holder.dataset.taReady = '1';

    const html = await fetch('assets/views/trading-account/trading-account.html').then(r => r.text());
    holder.innerHTML = html;
    bindStaticUi();
    await loadAccounts();
  };

  window.CP_onViewShow['trading-account'] = function () {
    const holder = document.getElementById('trading-account-root');
    if (holder && holder.dataset.taReady === '1') loadAccounts();
  };

  window.__taReloadAccounts = loadAccounts;
})();
