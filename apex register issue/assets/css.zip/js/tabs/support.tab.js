// Support tab — Contacts, Tickets, Meetings (session-backed API proxies)
window.CP_tabs = window.CP_tabs || {};
window.CP_onViewShow = window.CP_onViewShow || {};

(function () {
  const LIST = 'api/support/tickets_list.php';
  const GET = 'api/support/ticket_get.php';
  const CREATE = 'api/support/ticket_create.php';
  const COMMENT = 'api/support/ticket_comment.php';
  const PATCH = 'api/support/ticket_patch.php';
  const DEPT_API = 'api/support/ticket_departments.php';
  const MEET_LIST = 'api/support/meetings_list.php';
  const MEET_CREATE = 'api/support/meeting_create.php';
  const MEET_SLOTS = 'api/support/meeting_time_slots.php';
  const MEET_DELETE = 'api/support/meeting_delete.php';
  const MEET_UPDATE = 'api/support/meeting_update.php';

  /** Optional label for default department UUID (display only). */
  const DEPT_LABELS = {
    '01cbe2c0-0e16-45e7-8f2b-e7e4e2836aaf': 'test department'
  };

  let tickets = [];
  /** Ticket departments from GET clientzone/lead/ticket/department */
  let departments = [];
  let meetings = [];
  let expandedId = null;
  let ticketDetails = {};

  /** Meetings: schedule modal */
  let meetEditId = null;
  let meetCalView = null;
  let meetSelectedDate = null;
  let meetCancelId = null;

  /** Tickets list pagination (open / closed each paginated separately via filter) */
  let ticketPage = 1;
  const TICKETS_PAGE_SIZE = 10;

  function $(sel, root) {
    return (root || document).querySelector(sel);
  }

  function escapeHtml(s) {
    return String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function initials() {
    const u = window.CP_USER;
    if (!u) return '—';
    const f = (u.firstName || '').trim();
    const l = (u.lastName || '').trim();
    let t = '';
    if (f) t += f.charAt(0).toUpperCase();
    if (l) t += l.charAt(0).toUpperCase();
    if (t) return t;
    const em = (u.email || '').trim();
    if (em) return em.split('@')[0].slice(0, 2).toUpperCase();
    return '—';
  }

  function formatDt(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return escapeHtml(String(iso));
    const pad = (n) => String(n).padStart(2, '0');
    return `${pad(d.getDate())}-${pad(d.getMonth() + 1)}-${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  function formatYMD(d) {
    if (!d || Number.isNaN(d.getTime())) return '';
    const pad = (n) => String(n).padStart(2, '0');
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  function formatLongMeeting(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return escapeHtml(String(iso));
    return d.toLocaleString(undefined, {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  function formatOrdinalDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '—';
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const day = d.getDate();
    const k = day % 100;
    const j = day % 10;
    let ord = 'th';
    if (j === 1 && k !== 11) ord = 'st';
    else if (j === 2 && k !== 12) ord = 'nd';
    else if (j === 3 && k !== 13) ord = 'rd';
    return day + ord + ' ' + months[d.getMonth()] + ' ' + d.getFullYear();
  }

  function parseSlotStart(slotStr) {
    const m = normalizeSlotLabel(slotStr).match(/^(\d{1,2}):(\d{2})/);
    if (!m) return null;
    return { h: parseInt(m[1], 10), mi: parseInt(m[2], 10) };
  }

  function normalizeSlotLabel(slotStr) {
    return String(slotStr || '')
      .replace(/\u2013/g, '-')
      .replace(/\u2014/g, '-')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function parseSlotRange(slotStr) {
    const m = normalizeSlotLabel(slotStr).match(/^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})/);
    if (!m) return null;
    const sh = parseInt(m[1], 10);
    const sm = parseInt(m[2], 10);
    const eh = parseInt(m[3], 10);
    const em = parseInt(m[4], 10);
    const start = sh * 60 + sm;
    let end = eh * 60 + em;
    if (end < start) end += 24 * 60;
    return { start, end, span: end - start };
  }

  function minutesToHHMM(total) {
    const h = Math.floor(total / 60) % 24;
    const mi = total % 60;
    return String(h).padStart(2, '0') + ':' + String(mi).padStart(2, '0');
  }

  /** API may use isDisabled, disabled, available, etc. */
  function slotIsDisabled(s) {
    if (s == null || typeof s !== 'object') return false;
    if (s.isDisabled === true || s.disabled === true) return true;
    if (s.isDisabled === false || s.disabled === false) return false;
    if (s.available === false) return true;
    if (s.isBooked === true || s.booked === true) return true;
    const a = s.isDisabled;
    if (typeof a === 'string') {
      const t = a.toLowerCase();
      return t === 'true' || t === '1' || t === 'yes';
    }
    const d = s.disabled;
    if (typeof d === 'string') {
      const t = d.toLowerCase();
      return t === 'true' || t === '1' || t === 'yes';
    }
    return false;
  }

  function applySlotSelection(slotEl, preferPrefix) {
    if (!slotEl || slotEl.options.length <= 1) return;
    if (preferPrefix) {
      for (let i = 1; i < slotEl.options.length; i++) {
        const o = slotEl.options[i];
        if (o.value && o.value.indexOf(preferPrefix) === 0 && !o.disabled) {
          slotEl.selectedIndex = i;
          return;
        }
      }
    }
    for (let i = 1; i < slotEl.options.length; i++) {
      const o = slotEl.options[i];
      if (o.value && !o.disabled) {
        slotEl.selectedIndex = i;
        return;
      }
    }
    slotEl.selectedIndex = 0;
  }

  /** Reference hourly list: last start is 21:00 (21:00 - 22:00); no 21:30+ starts */
  const HOURLY_LAST_START_MIN = 21 * 60;

  /**
   * Build reference-style 1-hour options from 30-minute API rows (sliding pairs).
   * Same labels as Chakra: 00:00 - 01:00, 00:30 - 01:30, …, 21:00 - 22:00
   */
  function normalizeSlotsForHourly(slots) {
    if (!Array.isArray(slots) || slots.length < 2) return slots;
    const v0 = normalizeSlotLabel(slotObjectToLabel(slots[0]));
    const r0 = parseSlotRange(v0);
    if (r0 && r0.span === 60) return trimHourlySlotsToReference(slots);

    const out = [];
    for (let i = 0; i < slots.length - 1; i++) {
      const a = slots[i];
      const b = slots[i + 1];
      const va = normalizeSlotLabel(slotObjectToLabel(a));
      const vb = normalizeSlotLabel(slotObjectToLabel(b));
      const ra = parseSlotRange(va);
      const rb = parseSlotRange(vb);
      if (!ra || !rb || ra.span !== 30 || rb.span !== 30) continue;
      if (ra.end !== rb.start) continue;
      if (ra.start > HOURLY_LAST_START_MIN) continue;
      const disabled = slotIsDisabled(a) || slotIsDisabled(b);
      const combined = minutesToHHMM(ra.start) + ' - ' + minutesToHHMM(rb.end);
      out.push({ key: combined, value: combined, isDisabled: disabled });
    }
    return out.length ? out : slots;
  }

  function trimHourlySlotsToReference(slots) {
    if (!Array.isArray(slots)) return slots;
    return slots.filter((s) => {
      const v = normalizeSlotLabel(s.value != null ? s.value : s.key);
      const r = parseSlotRange(v);
      if (!r || r.span !== 60) return true;
      return r.start <= HOURLY_LAST_START_MIN;
    });
  }

  function slotObjectToLabel(s) {
    if (s == null) return '';
    if (typeof s === 'string') return s;
    if (typeof s === 'object') {
      if (s.value != null) return String(s.value);
      if (s.key != null) return String(s.key);
      if (s.label != null) return String(s.label);
      if (s.from != null && s.to != null) return `${s.from} - ${s.to}`;
    }
    return '';
  }

  function sortSlotsByStartTime(slots) {
    if (!Array.isArray(slots)) return slots;
    return [...slots].sort((a, b) => {
      const va = parseSlotRange(normalizeSlotLabel(slotObjectToLabel(a)));
      const vb = parseSlotRange(normalizeSlotLabel(slotObjectToLabel(b)));
      if (!va || !vb) return 0;
      return va.start - vb.start;
    });
  }

  /** For the selected calendar day: disable slot if its start time is already in the past (today only). */
  function applyPastTimeDisabling(slots, day) {
    if (!Array.isArray(slots) || !day) return slots;
    const now = new Date();
    const d0 = new Date(day.getFullYear(), day.getMonth(), day.getDate());
    const t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if (d0.getTime() !== t0.getTime()) return slots;

    return slots.map((s) => {
      const val = normalizeSlotLabel(slotObjectToLabel(s));
      const t = parseSlotStart(val);
      if (!t) return s;
      const slotStart = new Date(day.getFullYear(), day.getMonth(), day.getDate(), t.h, t.mi, 0, 0);
      const inPast = slotStart.getTime() < now.getTime();
      const apiOff = slotIsDisabled(s);
      return Object.assign({}, s, { value: val, key: val, isDisabled: inPast || apiOff });
    });
  }

  function combineDateAndSlot(day, slotValue) {
    const t = parseSlotStart(slotValue);
    if (!t || !day) return null;
    return new Date(day.getFullYear(), day.getMonth(), day.getDate(), t.h, t.mi, 0, 0);
  }

  function deptLabel(id) {
    if (!id) return '—';
    const d = departments.find((x) => String(x.id) === String(id));
    if (d) {
      const n = d.name || (d.localization && d.localization.en && d.localization.en.name);
      if (n) return String(n);
    }
    return DEPT_LABELS[id] || id.slice(0, 8) + '…';
  }

  function ticketStatusBadgeClass(status) {
    const s = String(status || '').toLowerCase();
    if (s === 'new') return 'sup-ticket-status sup-ticket-status--new';
    if (s === 'closed') return 'sup-ticket-status sup-ticket-status--closed';
    return 'sup-ticket-status sup-ticket-status--default';
  }

  async function loadDepartments() {
    try {
      const res = await fetch(DEPT_API, { credentials: 'same-origin' });
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        throw new Error(data.message || 'Could not load departments');
      }
      departments = Array.isArray(data.data) ? data.data : [];
      const sel = $('#supNewDepartment');
      if (sel) {
        const prev = sel.value;
        sel.innerHTML = '<option value="">Select A department</option>';
        departments.forEach((d) => {
          const opt = document.createElement('option');
          opt.value = d.id;
          opt.textContent =
            d.name || (d.localization && d.localization.en && d.localization.en.name) || d.id;
          sel.appendChild(opt);
        });
        if (prev && departments.some((x) => String(x.id) === String(prev))) {
          sel.value = prev;
        }
      }
    } catch (e) {
      departments = [];
      console.warn('[support] departments:', e);
    }
  }

  function isClosed(t) {
    const s = String(t.status || '').toLowerCase();
    return s === 'closed';
  }

  function ticketCreatedMs(t) {
    const raw = t && (t.createdAt || t.created || t.updatedAt);
    const d = raw ? new Date(raw) : new Date(0);
    const ms = d.getTime();
    return Number.isNaN(ms) ? 0 : ms;
  }

  function sortTicketsNewestFirst(arr) {
    arr.sort((a, b) => ticketCreatedMs(b) - ticketCreatedMs(a));
  }

  function showGlobal(msg, kind) {
    const el = $('#supGlobalMsg');
    if (!el) return;
    el.textContent = msg || '';
    el.classList.remove('d-none', 'sup-msg--ok', 'sup-msg--err');
    if (!msg) {
      el.classList.add('d-none');
      return;
    }
    el.classList.add(kind === 'err' ? 'sup-msg--err' : 'sup-msg--ok');
  }

  function setContactsMailto() {
    const a = $('#supMailtoCard');
    if (!a) return;
    const email = 'portal@clientzone.ai';
    a.href = 'mailto:' + encodeURIComponent(email) + '?subject=' + encodeURIComponent('Support request');
  }

  function setActiveTab(name) {
    document.querySelectorAll('.sup-tab').forEach((btn) => {
      const on = btn.dataset.supTab === name;
      btn.classList.toggle('sup-tab--active', on);
      btn.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    const panels = {
      contacts: $('#supPanelContacts'),
      tickets: $('#supPanelTickets'),
      meetings: $('#supPanelMeetings')
    };
    Object.keys(panels).forEach((key) => {
      const p = panels[key];
      if (!p) return;
      const show = key === name;
      p.classList.toggle('d-none', !show);
      p.hidden = !show;
    });
  }

  async function loadTickets(opts) {
    const keepPage = opts && opts.keepPage === true;
    const loading = $('#supTicketsLoading');
    const empty = $('#supTicketsEmpty');
    const listEl = $('#supTicketsList');
    if (loading) loading.classList.remove('d-none');
    if (empty) empty.classList.add('d-none');
    if (listEl) listEl.innerHTML = '';

    try {
      const res = await fetch(LIST, { credentials: 'same-origin' });
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        throw new Error(data.message || 'Could not load tickets');
      }
      tickets = Array.isArray(data.data) ? data.data : [];
      sortTicketsNewestFirst(tickets);
      ticketDetails = {};
      if (!keepPage) ticketPage = 1;
      renderTickets();
    } catch (e) {
      showGlobal(e.message || 'Failed to load tickets', 'err');
      tickets = [];
      if (!keepPage) ticketPage = 1;
      renderTickets();
    } finally {
      if (loading) loading.classList.add('d-none');
    }
  }

  function goToTicketPage(id) {
    const all = filteredTickets();
    const idx = all.findIndex((t) => String(t.id) === String(id));
    if (idx < 0) {
      ticketPage = 1;
      return;
    }
    const totalPages = Math.max(1, Math.ceil(all.length / TICKETS_PAGE_SIZE));
    ticketPage = Math.min(Math.floor(idx / TICKETS_PAGE_SIZE) + 1, totalPages);
  }

  /**
   * Compact page list: e.g. [1, …, 5, 6, 7, …, 47] instead of 1..47.
   */
  function buildTicketPaginationItems(current, total) {
    if (total <= 1) {
      return total === 1 ? [1] : [];
    }
    if (total <= 9) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }
    const items = [];
    items.push(1);
    let start = Math.max(2, current - 2);
    let end = Math.min(total - 1, current + 2);
    if (current <= 4) {
      start = 2;
      end = Math.min(6, total - 1);
    }
    if (current >= total - 3) {
      start = Math.max(2, total - 5);
      end = total - 1;
    }
    if (start > 2) items.push('ellipsis');
    for (let i = start; i <= end; i++) {
      items.push(i);
    }
    if (end < total - 1) items.push('ellipsis');
    if (items[items.length - 1] !== total) items.push(total);
    return items;
  }

  function renderTicketsPager(totalCount) {
    const pager = $('#supTicketsPager');
    if (!pager) return;
    const totalPages = Math.max(1, Math.ceil(totalCount / TICKETS_PAGE_SIZE) || 1);
    if (ticketPage > totalPages) ticketPage = totalPages;
    if (ticketPage < 1) ticketPage = 1;

    if (totalCount <= TICKETS_PAGE_SIZE) {
      pager.classList.add('d-none');
      pager.innerHTML = '';
      return;
    }

    const from = (ticketPage - 1) * TICKETS_PAGE_SIZE + 1;
    const to = Math.min(ticketPage * TICKETS_PAGE_SIZE, totalCount);
    pager.classList.remove('d-none');
    const pageItems = buildTicketPaginationItems(ticketPage, totalPages);
    let pagesHtml = '';
    pageItems.forEach((item) => {
      if (item === 'ellipsis') {
        pagesHtml += '<span class="dash-page-ellipsis" aria-hidden="true">…</span>';
        return;
      }
      const p = item;
      pagesHtml += `<button type="button" class="dash-page-btn${p === ticketPage ? ' is-active' : ''}" data-sup-page="${p}">${p}</button>`;
    });
    pager.innerHTML = `
      <div class="dash-pagination sup-tickets-dpagination" role="navigation" aria-label="Ticket list pages">
        <span class="sup-tickets-pageinfo text-muted small">Showing ${from}–${to} of ${totalCount}</span>
        <div class="sup-tickets-pagebtns">
          <button type="button" class="dash-page-btn dash-page-btn--arrow" data-sup-page="prev" ${ticketPage <= 1 ? 'disabled' : ''} aria-label="Previous">&lt;</button>
          ${pagesHtml}
          <button type="button" class="dash-page-btn dash-page-btn--arrow" data-sup-page="next" ${ticketPage >= totalPages ? 'disabled' : ''} aria-label="Next">&gt;</button>
        </div>
      </div>`;
  }

  async function ensureTicketDetail(id) {
    if (ticketDetails[id] && ticketDetails[id].userTicketComments) {
      return ticketDetails[id];
    }
    try {
      const res = await fetch(GET + '?id=' + encodeURIComponent(id), { credentials: 'same-origin' });
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        return null;
      }
      ticketDetails[id] = data.data;
      return data.data;
    } catch {
      return null;
    }
  }

  function currentFilter() {
    const r = document.querySelector('input[name="supTicketFilter"]:checked');
    return r && r.value === 'closed' ? 'closed' : 'open';
  }

  function filteredTickets() {
    const f = currentFilter();
    return tickets.filter((t) => (f === 'closed' ? isClosed(t) : !isClosed(t)));
  }

  function renderTickets() {
    const empty = $('#supTicketsEmpty');
    const listEl = $('#supTicketsList');
    if (!listEl) return;

    const all = filteredTickets();
    const totalCount = all.length;
    const totalPages = Math.max(1, Math.ceil(totalCount / TICKETS_PAGE_SIZE) || 1);
    if (ticketPage > totalPages) ticketPage = totalPages;
    if (ticketPage < 1) ticketPage = 1;

    const start = (ticketPage - 1) * TICKETS_PAGE_SIZE;
    const rows = all.slice(start, start + TICKETS_PAGE_SIZE);

    if (expandedId && !rows.some((x) => x.id === expandedId)) {
      expandedId = null;
    }
    if (empty) empty.classList.toggle('d-none', totalCount > 0);

    renderTicketsPager(totalCount);

    listEl.innerHTML = rows
      .map((t) => {
        const id = t.id || '';
        const open = expandedId === id;
        const cat = escapeHtml(t.category || '—');
        const title = escapeHtml(t.title || 'Ticket');
        const created = formatDt(t.createdAt);
        const stRaw = t.status || '—';
        const st = escapeHtml(stRaw);
        const dept = escapeHtml(deptLabel(t.departmentId));
        const stClass = ticketStatusBadgeClass(stRaw);
        return `
          <div class="sup-ticket${open ? ' sup-ticket--open' : ''}" data-ticket-id="${escapeHtml(id)}">
            <button type="button" class="sup-ticket-head" data-action="toggle-ticket" data-id="${escapeHtml(id)}">
              <div class="sup-ticket-head-left">
                <span class="${stClass}" aria-label="Status">${st}</span>
                <i class="bi bi-chat-dots sup-ticket-icon" aria-hidden="true"></i>
                <div class="sup-ticket-title-row">
                  <span class="sup-ticket-title">${title}</span>
                  <span class="sup-ticket-date">${created}</span>
                </div>
              </div>
              <div class="sup-ticket-head-meta">
                <span class="sup-ticket-kv-label">Category:</span>
                <span class="sup-ticket-kv-badge sup-ticket-kv-badge--cat">${cat}</span>
                <span class="sup-ticket-kv-label">Department:</span>
                <span class="sup-ticket-kv-badge sup-ticket-kv-badge--dept">${dept}</span>
              </div>
              <i class="bi bi-chevron-down sup-ticket-chevron" aria-hidden="true"></i>
            </button>
            <div class="sup-ticket-body" data-thread="${escapeHtml(id)}"></div>
          </div>`;
      })
      .join('');

    rows.forEach((t) => {
      const id = t.id;
      if (id && expandedId === id) {
        renderThread(id, t);
      }
    });
  }

  function sortComments(comments) {
    if (!Array.isArray(comments)) return [];
    return [...comments].sort((a, b) => {
      const ta = new Date(a.createdAt || 0).getTime();
      const tb = new Date(b.createdAt || 0).getTime();
      return ta - tb;
    });
  }

  function renderThread(ticketId, ticketFallback) {
    const body = document.querySelector('[data-thread="' + ticketId + '"]');
    if (!body) return;

    const detail = ticketDetails[ticketId] || ticketFallback;
    const comments = sortComments(detail.userTicketComments || []);
    const uid = window.CP_USER && window.CP_USER.userId ? String(window.CP_USER.userId) : '';

    const bubbles = comments
      .map((c) => {
        const mine = uid && String(c.userId || '') === uid;
        const text = escapeHtml(c.text || '');
        const ts = formatDt(c.createdAt);
        const av = mine ? escapeHtml(initials()) : 'A';
        return `
          <div class="sup-msg${mine ? ' sup-msg--user' : ' sup-msg--agent'}">
            <div class="sup-msg-av" aria-hidden="true">${av}</div>
            <div>
              <div class="sup-msg-bubble">${text}</div>
              <div class="sup-msg-time"><i class="bi bi-clock" aria-hidden="true"></i> ${ts}</div>
            </div>
          </div>`;
      })
      .join('');

    const closed = isClosed(detail);
    const replyBlock = closed
      ? '<p class="small text-muted mb-0">This ticket is closed.</p>'
      : `
        <div class="sup-reply">
          <label class="sup-field mb-0">
            <span>Reply</span>
            <textarea class="sup-textarea sup-reply-text" rows="2" placeholder="Type your message" data-ticket-id="${escapeHtml(ticketId)}"></textarea>
          </label>
          <div class="sup-reply-actions">
            <button type="button" class="sup-btn-primary sup-btn-send" data-id="${escapeHtml(ticketId)}">Send</button>
            <button type="button" class="sup-btn-danger sup-btn-close-ticket" data-id="${escapeHtml(ticketId)}">Close ticket</button>
          </div>
        </div>`;

    body.innerHTML = `<div class="sup-thread">${bubbles || '<p class="small text-muted">No messages yet.</p>'}</div>${replyBlock}`;
  }

  async function toggleTicket(id) {
    if (expandedId === id) {
      expandedId = null;
    } else {
      expandedId = id;
      const t = tickets.find((x) => x.id === id);
      const detail = await ensureTicketDetail(id);
      if (detail) {
        ticketDetails[id] = Object.assign({}, t || {}, detail);
      } else if (t) {
        ticketDetails[id] = t;
      }
    }
    renderTickets();
  }

  async function sendComment(ticketId) {
    const ta = document.querySelector('textarea.sup-reply-text[data-ticket-id="' + ticketId + '"]');
    const text = (ta && ta.value) ? ta.value.trim() : '';
    if (!text) {
      showGlobal('Please enter a message.', 'err');
      return;
    }
    showGlobal('', 'ok');
    try {
      const res = await fetch(COMMENT, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, userTicketId: ticketId })
      });
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        throw new Error(data.message || 'Failed to send');
      }
      if (ta) ta.value = '';
      delete ticketDetails[ticketId];
      await loadTickets({ keepPage: true });
      expandedId = ticketId;
      goToTicketPage(ticketId);
      const d = await ensureTicketDetail(ticketId);
      if (d) ticketDetails[ticketId] = d;
      renderTickets();
      showGlobal('Message sent.', 'ok');
      setTimeout(() => showGlobal('', 'ok'), 2500);
    } catch (e) {
      showGlobal(e.message || 'Failed to send', 'err');
    }
  }

  async function closeTicket(ticketId) {
    if (!window.confirm('Close this ticket? You can still view it under Closed tickets.')) return;
    showGlobal('', 'ok');
    try {
      const res = await fetch(PATCH + '?id=' + encodeURIComponent(ticketId), {
        method: 'PATCH',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'Closed' })
      });
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        throw new Error(data.message || 'Failed to close ticket');
      }
      expandedId = null;
      showGlobal('Ticket closed.', 'ok');
      setTimeout(() => showGlobal('', 'ok'), 2500);
      await loadTickets();
    } catch (e) {
      showGlobal(e.message || 'Failed to close', 'err');
    }
  }

  async function submitNewTicket(e) {
    e.preventDefault();
    const title = ($('#supNewTitle') && $('#supNewTitle').value.trim()) || '';
    const initialMessage = ($('#supNewBody') && $('#supNewBody').value.trim()) || '';
    const category = ($('#supNewCategory') && $('#supNewCategory').value) || 'General';
    const btn = $('#supNewSubmit');
    if (btn) btn.disabled = true;
    try {
      const res = await fetch(CREATE, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, initialMessage, category })
      });
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        throw new Error(data.message || 'Failed to create ticket');
      }
      const modalEl = document.getElementById('supModalNewTicket');
      if (modalEl && typeof bootstrap !== 'undefined') {
        const inst = bootstrap.Modal.getInstance(modalEl) || bootstrap.Modal.getOrCreateInstance(modalEl);
        inst.hide();
      }
      e.target.reset();
      const catSel = $('#supNewCategory');
      const depSel = $('#supNewDepartment');
      if (catSel) catSel.selectedIndex = 0;
      if (depSel) depSel.selectedIndex = 0;
      showGlobal('Ticket created.', 'ok');
      setTimeout(() => showGlobal('', 'ok'), 3000);
      await loadTickets();
    } catch (err) {
      showGlobal(err.message || 'Error', 'err');
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  function meetingStatusCanceled(m) {
    const s = String(m.status || '').toLowerCase();
    return s === 'canceled' || s === 'cancelled';
  }

  function renderMeetingsTable() {
    const tbody = $('#supMeetTableBody');
    const empty = $('#supMeetEmpty');
    const wrap = $('#supMeetTableWrap');
    if (!tbody) return;

    const sorted = [...meetings].sort((a, b) => {
      const ta = new Date(a.createdAt || 0).getTime();
      const tb = new Date(b.createdAt || 0).getTime();
      return tb - ta;
    });

    if (empty) empty.classList.toggle('d-none', sorted.length > 0);
    if (wrap) wrap.classList.toggle('d-none', sorted.length === 0);

    tbody.innerHTML = sorted
      .map((m) => {
        const id = escapeHtml(m.id || '');
        const canceled = meetingStatusCanceled(m);
        const stIcon = canceled
          ? '<span class="sup-meet-status-ico sup-meet-status-ico--done"><i class="bi bi-dash-lg"></i></span>'
          : '<span class="sup-meet-status-ico sup-meet-status-ico--pending"><i class="bi bi-three-dots"></i></span>';
        const created = formatLongMeeting(m.createdAt);
        const desc = escapeHtml((m.description || '').slice(0, 120)) + ((m.description || '').length > 120 ? '…' : '');
        const actions = canceled
          ? `<div class="sup-meet-actions">
          <button type="button" class="sup-btn-action" data-action="meet-preview" data-id="${id}"><i class="bi bi-eye"></i> Preview</button>
        </div>`
          : `<div class="sup-meet-actions">
          <button type="button" class="sup-btn-action" data-action="meet-reschedule" data-id="${id}"><i class="bi bi-calendar3"></i> Change date</button>
          <button type="button" class="sup-btn-action sup-btn-action--danger" data-action="meet-cancel" data-id="${id}"><i class="bi bi-x-lg"></i> Cancel</button>
          <button type="button" class="sup-btn-action" data-action="meet-preview" data-id="${id}"><i class="bi bi-eye"></i> Preview</button>
        </div>`;
        return `<tr>
        <td>${stIcon}</td>
        <td>${escapeHtml(created)}</td>
        <td class="sup-meet-desc">${desc || '—'}</td>
        <td>${actions}</td>
      </tr>`;
      })
      .join('');
  }

  async function loadMeetings() {
    const loading = $('#supMeetLoading');
    const tbody = $('#supMeetTableBody');
    if (loading) loading.classList.remove('d-none');
    if (tbody) tbody.innerHTML = '';

    try {
      const res = await fetch(MEET_LIST, { credentials: 'same-origin' });
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        throw new Error(data.message || 'Could not load meetings');
      }
      meetings = Array.isArray(data.data) ? data.data : [];
      renderMeetingsTable();
    } catch (e) {
      showGlobal(e.message || 'Failed to load meetings', 'err');
      meetings = [];
      renderMeetingsTable();
    } finally {
      if (loading) loading.classList.add('d-none');
    }
  }

  function updateMeetSelectedLabel() {
    const el = $('#supMeetSelectedLabel');
    if (!el || !meetSelectedDate) return;
    const noon = new Date(
      meetSelectedDate.getFullYear(),
      meetSelectedDate.getMonth(),
      meetSelectedDate.getDate(),
      12,
      0,
      0
    );
    el.textContent = formatOrdinalDate(noon.toISOString());
  }

  function renderCalendar() {
    const grid = $('#supCalGrid');
    const label = $('#supCalMonthLabel');
    if (!grid || !meetCalView) return;

    const y = meetCalView.getFullYear();
    const mo = meetCalView.getMonth();
    if (label) {
      label.textContent = meetCalView.toLocaleString(undefined, { month: 'long', year: 'numeric' });
    }

    const first = new Date(y, mo, 1);
    const startPad = first.getDay();
    const daysInMonth = new Date(y, mo + 1, 0).getDate();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const cells = [];
    for (let i = 0; i < startPad; i++) {
      cells.push('<div class="sup-cal-day sup-cal-day--muted"></div>');
    }
    for (let d = 1; d <= daysInMonth; d++) {
      const dayDate = new Date(y, mo, d);
      const isEditSameDay =
        meetEditId &&
        meetSelectedDate &&
        dayDate.getFullYear() === meetSelectedDate.getFullYear() &&
        dayDate.getMonth() === meetSelectedDate.getMonth() &&
        dayDate.getDate() === meetSelectedDate.getDate();
      const isPast = dayDate < today && !isEditSameDay;
      const isWeekend = dayDate.getDay() === 0 || dayDate.getDay() === 6;
      const isToday =
        dayDate.getFullYear() === today.getFullYear() &&
        dayDate.getMonth() === today.getMonth() &&
        dayDate.getDate() === today.getDate();
      const isSel =
        meetSelectedDate &&
        meetSelectedDate.getFullYear() === y &&
        meetSelectedDate.getMonth() === mo &&
        meetSelectedDate.getDate() === d;
      let cls = 'sup-cal-day';
      if (isWeekend) cls += ' sup-cal-day--weekend';
      if (isToday) cls += ' sup-cal-day--today';
      if (isSel) cls += ' sup-cal-day--selected';
      const dis = isPast ? ' disabled' : '';
      cells.push(
        `<button type="button" class="${cls}" data-cal-day="${d}"${dis}>${d}</button>`
      );
    }
    grid.innerHTML = cells.join('');

    grid.querySelectorAll('button[data-cal-day]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const d = parseInt(btn.getAttribute('data-cal-day'), 10);
        meetSelectedDate = new Date(y, mo, d);
        renderCalendar();
        updateMeetSelectedLabel();
        loadTimeSlots();
      });
    });
  }

  async function loadTimeSlots(selectValue) {
    const slotEl = $('#supSchedSlot');
    const durEl = $('#supSchedDuration');
    if (!slotEl || !meetSelectedDate) return;
    const dur = durEl ? parseInt(durEl.value, 10) || 30 : 30;
    /** Backend often returns the same 30-min list for both 30 and 60; merge needs that grid. */
    const apiDuration = dur === 60 ? 30 : dur;
    const ymd = formatYMD(meetSelectedDate);
    slotEl.innerHTML = '<option value="">Loading…</option>';
    slotEl.disabled = true;
    try {
      const res = await fetch(
        MEET_SLOTS + '?date=' + encodeURIComponent(ymd) + '&duration=' + encodeURIComponent(apiDuration),
        { credentials: 'same-origin' }
      );
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        throw new Error(data.message || 'Could not load time slots');
      }
      let slots = Array.isArray(data.data) ? data.data : [];
      if (!slots.length && data.data && typeof data.data === 'object') {
        slots = Object.values(data.data);
      }
      slots = slots.map((row) =>
        typeof row === 'string' ? { key: row, value: row, isDisabled: false } : row
      );

      const wantsOneHour = parseInt(String(durEl && durEl.value), 10) === 60;

      if (wantsOneHour) {
        slots = sortSlotsByStartTime(slots);
        slots = normalizeSlotsForHourly(slots);
      } else {
        slots = sortSlotsByStartTime(slots);
      }

      slots = applyPastTimeDisabling(slots, meetSelectedDate);

      slotEl.innerHTML = '<option value="">Please Select Meeting Time</option>';
      slots.forEach((s) => {
        const val = normalizeSlotLabel(slotObjectToLabel(s));
        const opt = document.createElement('option');
        opt.value = val;
        opt.textContent = val;
        if (slotIsDisabled(s)) opt.disabled = true;
        slotEl.appendChild(opt);
      });
      applySlotSelection(slotEl, selectValue || null);
    } catch (e) {
      slotEl.innerHTML = '<option value="">Please Select Meeting Time</option>';
      showGlobal(e.message || 'Time slots failed', 'err');
    } finally {
      slotEl.disabled = false;
    }
  }

  function openScheduleModal(editMeeting) {
    meetEditId = editMeeting && editMeeting.id ? editMeeting.id : null;
    const modalEl = document.getElementById('supModalSchedule');
    const titleEl = $('#supModalScheduleTitle');
    if (titleEl) {
      titleEl.textContent = meetEditId ? 'Change meeting date' : 'Schedule a meeting with your Agent';
    }

    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    todayStart.setHours(0, 0, 0, 0);

    if (editMeeting && editMeeting.date) {
      const d = new Date(editMeeting.date);
      meetSelectedDate = Number.isNaN(d.getTime()) ? new Date(todayStart) : d;
    } else {
      meetSelectedDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    }

    let bumpedPastMeetingToToday = false;
    if (meetEditId) {
      const sel = new Date(
        meetSelectedDate.getFullYear(),
        meetSelectedDate.getMonth(),
        meetSelectedDate.getDate()
      );
      sel.setHours(0, 0, 0, 0);
      if (sel < todayStart) {
        meetSelectedDate = new Date(todayStart);
        bumpedPastMeetingToToday = true;
      }
    }

    meetCalView = new Date(meetSelectedDate.getFullYear(), meetSelectedDate.getMonth(), 1);

    $('#supSchedTitle').value = editMeeting && editMeeting.title ? editMeeting.title : '';
    $('#supSchedDesc').value = editMeeting && editMeeting.description ? editMeeting.description : '';
    const imp =
      editMeeting && String(editMeeting.importance || '').toLowerCase() === 'urgent' ? true : false;
    const urgentEl = $('#supSchedUrgent');
    const urgentLabel = $('#supSchedUrgentLabel');
    if (urgentEl) urgentEl.checked = imp;
    if (urgentLabel) urgentLabel.textContent = imp ? 'Urgent' : 'Normal';

    const durEl = $('#supSchedDuration');
    if (durEl) {
      const p = parseInt(editMeeting && editMeeting.meetingPeriod, 10);
      durEl.value = p === 60 ? '60' : '30';
    }

    updateMeetSelectedLabel();
    renderCalendar();

    let preSlot = null;
    if (editMeeting && editMeeting.date && !bumpedPastMeetingToToday) {
      const md = new Date(editMeeting.date);
      const pad = (n) => String(n).padStart(2, '0');
      preSlot = pad(md.getHours()) + ':' + pad(md.getMinutes());
    }
    loadTimeSlots(preSlot);

    if (modalEl && typeof bootstrap !== 'undefined') {
      bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }
  }

  function openPreview(m) {
    const modal = document.getElementById('supModalMeetPreview');
    const st = $('#supPreviewStatus');
    const canceled = meetingStatusCanceled(m);
    if (st) {
      st.textContent = m.status || '—';
      st.className = 'sup-preview-badge' + (canceled ? ' sup-preview-badge--canceled' : '');
    }
    $('#supPreviewTitle').textContent = m.title || 'Meeting';
    $('#supPreviewDesc').textContent = m.description || '—';
    const period = String(m.meetingPeriod || '30');
    $('#supPreviewWhen').textContent =
      'Your meeting time is ' +
      period +
      ' minutes at ' +
      formatLongMeeting(m.date) +
      '.';
    const impEl = $('#supPreviewImp');
    if (impEl) {
      const raw = String(m.importance || 'normal').trim();
      impEl.textContent = raw ? raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase() : 'Normal';
    }
    if (modal && typeof bootstrap !== 'undefined') {
      bootstrap.Modal.getOrCreateInstance(modal).show();
    }
  }

  async function submitScheduleForm(e) {
    e.preventDefault();
    const title = ($('#supSchedTitle') && $('#supSchedTitle').value.trim()) || '';
    const description = ($('#supSchedDesc') && $('#supSchedDesc').value.trim()) || '';
    const slotVal = ($('#supSchedSlot') && $('#supSchedSlot').value) || '';
    const meetingPeriod = parseInt(($('#supSchedDuration') && $('#supSchedDuration').value) || '30', 10);
    const importance = $('#supSchedUrgent') && $('#supSchedUrgent').checked ? 'urgent' : 'normal';
    const btn = $('#supSchedSubmit');

    if (!meetSelectedDate || !slotVal) {
      showGlobal('Please choose a date and time slot.', 'err');
      return;
    }
    const slotSelect = $('#supSchedSlot');
    const selOpt = slotSelect && slotSelect.selectedOptions && slotSelect.selectedOptions[0];
    if (selOpt && selOpt.disabled) {
      showGlobal('That time slot is not available. Please choose another.', 'err');
      return;
    }
    const combined = combineDateAndSlot(meetSelectedDate, slotVal);
    if (!combined) {
      showGlobal('Invalid time slot.', 'err');
      return;
    }
    const dateIso = combined.toISOString();

    if (btn) btn.disabled = true;
    try {
      if (meetEditId) {
        const res = await fetch(MEET_UPDATE + '?id=' + encodeURIComponent(meetEditId), {
          method: 'PATCH',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            date: dateIso,
            title,
            description,
            importance,
            meetingPeriod,
            isUserConfirmed: true
          })
        });
        const data = await res.json();
        if (!res.ok || data.status === 'error') {
          throw new Error(data.message || 'Failed to update meeting');
        }
        showGlobal('Meeting updated.', 'ok');
      } else {
        const res = await fetch(MEET_CREATE, {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title,
            description,
            date: dateIso,
            meetingPeriod,
            importance,
            isUserConfirmed: true
          })
        });
        const data = await res.json();
        if (!res.ok || data.status === 'error') {
          throw new Error(data.message || 'Failed to schedule');
        }
        showGlobal('Meeting request submitted.', 'ok');
      }
      const modalEl = document.getElementById('supModalSchedule');
      if (modalEl && typeof bootstrap !== 'undefined') {
        bootstrap.Modal.getOrCreateInstance(modalEl).hide();
      }
      e.target.reset();
      meetEditId = null;
      setTimeout(() => showGlobal('', 'ok'), 2800);
      await loadMeetings();
    } catch (err) {
      showGlobal(err.message || 'Error', 'err');
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  async function deleteMeeting(id) {
    try {
      const res = await fetch(MEET_DELETE + '?id=' + encodeURIComponent(id), {
        method: 'DELETE',
        credentials: 'same-origin'
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error((data && data.message) || 'Failed to cancel meeting');
      }
      showGlobal('Meeting canceled.', 'ok');
      setTimeout(() => showGlobal('', 'ok'), 2500);
      await loadMeetings();
    } catch (err) {
      showGlobal(err.message || 'Cancel failed', 'err');
    }
  }

  function wire() {
    const root = $('#supRoot');
    if (!root || root.dataset.supWired === '1') return;
    root.dataset.supWired = '1';

    setContactsMailto();

    document.querySelectorAll('.sup-tab').forEach((btn) => {
      btn.addEventListener('click', () => {
        const name = btn.dataset.supTab;
        if (!name) return;
        setActiveTab(name);
        if (name === 'tickets') loadTickets();
        if (name === 'meetings') loadMeetings();
      });
    });

    document.querySelectorAll('input[name="supTicketFilter"]').forEach((r) => {
      r.addEventListener('change', () => {
        expandedId = null;
        ticketPage = 1;
        renderTickets();
      });
    });

    $('#supTicketsPager')?.addEventListener('click', (ev) => {
      const btn = ev.target.closest('[data-sup-page]');
      if (!btn || btn.disabled) return;
      const raw = btn.getAttribute('data-sup-page');
      const all = filteredTickets();
      const totalPages = Math.max(1, Math.ceil(all.length / TICKETS_PAGE_SIZE));
      if (raw === 'prev' && ticketPage > 1) {
        ticketPage -= 1;
        expandedId = null;
        renderTickets();
        return;
      }
      if (raw === 'next' && ticketPage < totalPages) {
        ticketPage += 1;
        expandedId = null;
        renderTickets();
        return;
      }
      const p = parseInt(raw, 10);
      if (!Number.isNaN(p) && p >= 1 && p <= totalPages) {
        ticketPage = p;
        expandedId = null;
        renderTickets();
      }
    });

    $('#supBtnAddTicket')?.addEventListener('click', async () => {
      await loadDepartments();
      const el = document.getElementById('supModalNewTicket');
      if (el && typeof bootstrap !== 'undefined') {
        bootstrap.Modal.getOrCreateInstance(el).show();
      }
    });

    $('#supFormNewTicket')?.addEventListener('submit', submitNewTicket);

    $('#supBtnOpenSchedule')?.addEventListener('click', () => openScheduleModal(null));

    $('#supFormSchedule')?.addEventListener('submit', submitScheduleForm);

    $('#supCalPrevM')?.addEventListener('click', () => {
      if (!meetCalView) return;
      meetCalView.setMonth(meetCalView.getMonth() - 1);
      renderCalendar();
    });
    $('#supCalNextM')?.addEventListener('click', () => {
      if (!meetCalView) return;
      meetCalView.setMonth(meetCalView.getMonth() + 1);
      renderCalendar();
    });

    $('#supSchedDuration')?.addEventListener('change', () => loadTimeSlots());

    $('#supSchedUrgent')?.addEventListener('change', () => {
      const el = $('#supSchedUrgent');
      const lb = $('#supSchedUrgentLabel');
      if (lb && el) lb.textContent = el.checked ? 'Urgent' : 'Normal';
    });

    $('#supPanelMeetings')?.addEventListener('click', (ev) => {
      const prev = ev.target.closest('[data-action="meet-preview"]');
      const can = ev.target.closest('[data-action="meet-cancel"]');
      const resched = ev.target.closest('[data-action="meet-reschedule"]');
      if (prev) {
        const id = prev.getAttribute('data-id');
        const m = meetings.find((x) => String(x.id) === String(id));
        if (m) openPreview(m);
        return;
      }
      if (resched) {
        const id = resched.getAttribute('data-id');
        const m = meetings.find((x) => String(x.id) === String(id));
        if (m) openScheduleModal(m);
        return;
      }
      if (can) {
        meetCancelId = can.getAttribute('data-id');
        const modal = document.getElementById('supModalMeetCancel');
        if (modal && typeof bootstrap !== 'undefined') {
          bootstrap.Modal.getOrCreateInstance(modal).show();
        }
      }
    });

    $('#supCancelConfirmYes')?.addEventListener('click', async () => {
      if (!meetCancelId) return;
      const id = meetCancelId;
      meetCancelId = null;
      const modal = document.getElementById('supModalMeetCancel');
      if (modal && typeof bootstrap !== 'undefined') {
        bootstrap.Modal.getOrCreateInstance(modal).hide();
      }
      await deleteMeeting(id);
    });

    $('#supTicketsList')?.addEventListener('click', async (ev) => {
      const toggle = ev.target.closest('[data-action="toggle-ticket"]');
      if (toggle) {
        const id = toggle.getAttribute('data-id');
        if (id) await toggleTicket(id);
        return;
      }
      const send = ev.target.closest('.sup-btn-send');
      if (send) {
        const id = send.getAttribute('data-id');
        if (id) await sendComment(id);
        return;
      }
      const close = ev.target.closest('.sup-btn-close-ticket');
      if (close) {
        const id = close.getAttribute('data-id');
        if (id) await closeTicket(id);
      }
    });
  }

  window.CP_tabs.support = function () {
    wire();
    setActiveTab('contacts');
  };

  window.CP_onViewShow.support = function () {
    setContactsMailto();
    const ticketsPanel = $('#supPanelTickets');
    if (ticketsPanel && !ticketsPanel.classList.contains('d-none')) {
      (async () => {
        await loadDepartments();
        await loadTickets();
      })();
    }
    const meetPanel = $('#supPanelMeetings');
    if (meetPanel && !meetPanel.classList.contains('d-none')) {
      loadMeetings();
    }
  };
})();
