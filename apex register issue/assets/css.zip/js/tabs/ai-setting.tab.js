// assets/js/tabs/ai-setting.tab.js � Figma AI Setting layout
window.CP_tabs = window.CP_tabs || {};
window.CP_state = window.CP_state || {};
window.CP_onViewShow = window.CP_onViewShow || {};

window.CP_tabs['ai-setting'] = function () {
  const rootSection = document.querySelector('section.view[data-view="ai-setting"]');
  if (!rootSection) return;

  const root = document.getElementById('ai-setting-view-root') || rootSection;

  function loadHtml() {
    if (root.querySelector('.ai-shell')) {
      initAiSetting();
      return;
    }
    const url =
      typeof window.CP_fetchView === 'function'
        ? window.CP_fetchView('assets/views/ai-setting/ai-setting.html')
        : fetch(new URL('assets/views/ai-setting/ai-setting.html', window.location.href).toString() + '?v=' + Date.now(), {
            credentials: 'same-origin'
          }).then((r) => {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.text();
          });

    Promise.resolve(url)
      .then((html) => {
        if (typeof html === 'string') {
          root.innerHTML = html;
          initAiSetting();
        }
      })
      .catch((err) => {
        console.error('ai-setting template error', err);
        root.innerHTML = '<div class="text-danger p-3">Failed to load AI Setting view.</div>';
      });
  }

  loadHtml();

  function initAiSetting() {
    const balanceEl = document.getElementById('aiCurrentBalance');
    const balanceNote = document.getElementById('aiBalanceNote');
    const rangeInput = document.getElementById('aiRange');
    const rangeTooltip = document.getElementById('aiRangeTooltip');
    const rangeMinLbl = document.getElementById('aiRangeMinLabel');
    const rangeMaxLbl = document.getElementById('aiRangeMaxLabel');
    const profitBadge = document.getElementById('aiProfitBadge');
    const successRateEl = document.getElementById('aiSuccessRate');
    const riskPills = document.querySelectorAll('.ai-risk-pill');
    const termsChk = document.getElementById('aiTerms');
    const investBtn = document.getElementById('aiInvestBtn');
    const investMsg = document.getElementById('aiInvestMsg');
    const termsLink = document.getElementById('aiTermsLink');
    const termsModal = document.getElementById('aiTermsModal');
    const termsClose = document.getElementById('aiTermsClose');
    const popover = document.getElementById('aiMarketPopover');
    const popoverBody = document.getElementById('aiMarketPopoverBody');
    const popoverClose = document.getElementById('aiMarketPopoverClose');
    const popoverOk = document.getElementById('aiMarketPopoverOk');

    let currentBalance = 0;
    let selectedRisk = 'low';

    const riskConfig = {
      low: { percent: 0.05, successRate: '82.3%', maxMargin: 10 },
      medium: { percent: 0.06, successRate: '74.5%', maxMargin: 25 },
      high: { percent: 0.07, successRate: '66.2%', maxMargin: 50 }
    };

    /* Market info popovers � copy for Forex, Crypto, Commodities, Stocks, Indices (asset row). */
    const POPOVER_HTML = {
      forex: `<h4 class="ai-popover-title">Forex (Foreign Exchange)</h4>
<ul class="ai-popover-list">
<li><strong>What it is:</strong> Trading of currency pairs (e.g., EUR/USD, GBP/JPY) in the world's largest and most liquid financial market.</li>
<li><strong>Typical users:</strong> Retail traders, banks, hedge funds, governments.</li>
<li><strong>Leverage:</strong> High (often 1:200 for retail, higher for professionals) you have 1:200</li>
<li><strong>Volatility:</strong> High (can be very high during news).</li>
<li><strong>Liquidity:</strong> Extremely high.</li>
<li><strong>Risk Level:</strong> Medium to High</li>
</ul>
<p class="ai-popover-foot">Forex is affected by economic data, interest rates, geopolitics, and central bank policies. High leverage increases the risk of significant losses. Market is open 24/5.</p>`,
      crypto: `<h4 class="ai-popover-title">Crypto</h4>
<ul class="ai-popover-list">
<li><strong>What it is:</strong> Digital currencies (e.g., Bitcoin, Ethereum) traded on decentralized or centralized exchanges.</li>
<li><strong>Typical users:</strong> Retail and institutional investors, speculators.</li>
<li><strong>Leverage:</strong> Available, but often lower than Forex (varies by platform and jurisdiction) You have 1:5.</li>
<li><strong>Volatility:</strong> Very High (large price swings, often double-digit % moves).</li>
<li><strong>Liquidity:</strong> Variable (major coins have good liquidity, smaller ones less so).</li>
<li><strong>Risk Level:</strong> High to Very High</li>
</ul>
<p class="ai-popover-foot">Crypto markets are open 24/7, can move sharply due to sentiment, regulation, hacks, or technological changes. Many coins are unregulated.</p>`,
      commodities: `<h4 class="ai-popover-title">Commodities</h4>
<ul class="ai-popover-list">
<li><strong>What it is:</strong> Physical goods like gold, oil, silver, agricultural products, traded via futures, spot, or CFDs.</li>
<li><strong>Typical users:</strong> Traders, investors, producers, corporations.</li>
<li><strong>Leverage:</strong> Varies (often significant via futures and CFDs) You have 1:50.</li>
<li><strong>Volatility:</strong> Medium to High (depends on the commodity, e.g., oil is more volatile than gold).</li>
<li><strong>Liquidity:</strong> High for major commodities, lower for niche markets.</li>
<li><strong>Risk Level:</strong> Medium to High</li>
</ul>
<p class="ai-popover-foot">Prices affected by global supply/demand, weather, politics, economic cycles. Some (like gold) are seen as &ldquo;safe havens,&rdquo; others (like oil or agricultural products) are much more volatile.</p>`,
      stocks: `<h4 class="ai-popover-title">Stocks</h4>
<ul class="ai-popover-list">
<li><strong>What it is:</strong> Ownership in publicly traded companies.</li>
<li><strong>Typical users:</strong> Retail and institutional investors.</li>
<li><strong>Leverage:</strong> Low in most cases (unless using margin or CFDs) You have 1:10.</li>
<li><strong>Volatility:</strong> Low to Medium (blue chips are less volatile, small caps more so).</li>
<li><strong>Liquidity:</strong> High for large companies, can be low for small or exotic stocks.</li>
<li><strong>Risk Level:</strong> Low to Medium (varies widely)</li>
</ul>
<p class="ai-popover-foot">Stock prices move based on company performance, earnings, news, and overall market sentiment. Generally considered less risky over the long-term, but individual companies can be highly risky.</p>`,
      indices: `<h4 class="ai-popover-title">Indices</h4>
<ul class="ai-popover-list">
<li><strong>What it is:</strong> Baskets of stocks representing a sector or country (e.g., S&amp;P 500, NASDAQ, FTSE 100).</li>
<li><strong>Typical users:</strong> Investors, traders, institutions.</li>
<li><strong>Leverage:</strong> Available via CFDs and futures. You have 1:50</li>
<li><strong>Volatility:</strong> Low-Medium (less than single stocks, but can spike in crises).</li>
<li><strong>Liquidity:</strong> Very high (major indices).</li>
<li><strong>Risk Level:</strong> Low - Medium</li>
</ul>
<p class="ai-popover-foot">Indices smooth out individual stock risk, but can still be volatile in bear markets or crises. Generally less risky than trading individual stocks, but more risky than cash or bonds.</p>`
    };

    function formatMoney2(num) {
      const n = Number(num) || 0;
      return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function formatMoney1(num) {
      const n = Number(num) || 0;
      return n.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
    }

    function paintRangeTrack() {
      if (!rangeInput) return;
      const min = Number(rangeInput.min) || 0;
      const max = Number(rangeInput.max) || 0;
      const val = Number(rangeInput.value) || 0;
      const pct = max <= min ? 0 : ((val - min) / (max - min)) * 100;
      rangeInput.style.setProperty('--ai-range-fill', pct + '%');
    }

    function positionTooltip() {
      if (!rangeInput || !rangeTooltip) return;
      const min = Number(rangeInput.min) || 0;
      const max = Number(rangeInput.max) || 0;
      const val = Number(rangeInput.value) || 0;
      const pct = max <= min ? 0 : ((val - min) / (max - min)) * 100;
      rangeTooltip.style.left = pct + '%';
      rangeTooltip.textContent = '$' + formatMoney1(val);
    }

    function syncFromGlobal() {
      const state = window.CP_state || {};
      const accounts = state.accounts || [];
      if (!accounts.length) return;

      let acc = null;
      if (state.selectedTp) {
        acc = accounts.find((a) => a.tpNumber === state.selectedTp);
      }
      if (!acc) {
        acc = accounts.find((a) => !a.isDemoAccount && !a.isArchived) || accounts[0];
      }
      if (!acc) return;

      window.CP_state.selectedTp = acc.tpNumber;
      currentBalance = parseFloat(acc.balance || 0) || 0;

      if (termsChk) termsChk.checked = false;
      if (investMsg) {
        investMsg.textContent = '';
        investMsg.classList.remove('error', 'success');
      }

      if (balanceEl) balanceEl.textContent = '$' + formatMoney2(currentBalance);

      if (balanceNote) {
        if (currentBalance <= 0) {
          balanceNote.textContent = '(Current balance is low)';
          balanceNote.hidden = false;
        } else {
          balanceNote.textContent = '';
          balanceNote.hidden = true;
        }
      }

      if (rangeInput && rangeMinLbl && rangeMaxLbl) {
        const maxVal = Math.max(0, Math.floor(currentBalance));
        rangeInput.max = String(maxVal);
        if (Number(rangeInput.value) > maxVal) rangeInput.value = String(maxVal);
        rangeMinLbl.textContent = '0';
        rangeMaxLbl.textContent = '$' + formatMoney2(currentBalance);
        paintRangeTrack();
        positionTooltip();
      }

      updateSummary();
      updateMarketAccess();
    }

    window.CP_onViewShow['ai-setting'] = syncFromGlobal;

    loadAccountsFromApi().then(() => {
      setupEvents();
      syncFromGlobal();
    });

    async function loadAccountsFromApi() {
      try {
        const res = await fetch('api/accounts/get_accounts.php', { credentials: 'same-origin' });
        const data = await res.json();
        if (!res.ok || data.status === 'error') return;
        const accounts = (data.data || []).filter((a) => !a.isArchived);
        if (!accounts.length) return;
        window.CP_state.accounts = accounts;
        if (!window.CP_state.selectedTp) {
          const acc0 = accounts.find((a) => !a.isDemoAccount && !a.isArchived) || accounts[0];
          if (acc0) window.CP_state.selectedTp = acc0.tpNumber;
        }
      } catch (e) {
        console.error('AI Setting accounts', e);
      }
    }

    function updateSummary() {
      const cfg = riskConfig[selectedRisk] || riskConfig.low;
      const rangeVal = rangeInput ? Number(rangeInput.value) || 0 : 0;
      const profitAmount = rangeVal * cfg.percent;
      const exposurePercent = Math.round(cfg.percent * 100);
      const riskLabel = selectedRisk.charAt(0).toUpperCase() + selectedRisk.slice(1);

      if (profitBadge) {
        profitBadge.textContent =
          `upto ${exposurePercent}%($${formatMoney2(profitAmount)}) with ${riskLabel} Risk`;
      }
      if (successRateEl) {
        successRateEl.innerHTML =
          'Success rate <span class="ai-profit-rate__pct">' + cfg.successRate + '</span>';
      }
    }

    function updateMarketAccess() {
      const items = document.querySelectorAll('.ai-asset-pill__item');
      const allowed = getAllowedMarkets(currentBalance);

      items.forEach((btn) => {
        const id = btn.dataset.market;
        if (!id) return;
        const icon = btn.querySelector('.ai-asset-pill__icon');
        const isOn = allowed.includes(id);

        btn.classList.toggle('unlocked', isOn);
        btn.classList.toggle('locked', !isOn);
        if (icon) {
          icon.className = 'bi ai-asset-pill__icon ' + (isOn ? 'bi-unlock' : 'bi-lock-fill');
        }
      });
    }

    function getAllowedMarkets(balance) {
      const b = Number(balance) || 0;
      if (b <= 1000) return ['forex', 'crypto'];
      if (b <= 2500) return ['forex', 'crypto'];
      if (b <= 5000) return ['forex', 'crypto', 'commodities', 'stocks'];
      return ['forex', 'crypto', 'commodities', 'stocks', 'indices'];
    }

    function setupEvents() {
      if (rangeInput) {
        rangeInput.addEventListener('input', () => {
          paintRangeTrack();
          positionTooltip();
          updateSummary();
        });
      }

      riskPills.forEach((pill) => {
        pill.addEventListener('click', () => {
          riskPills.forEach((p) => p.classList.remove('active'));
          pill.classList.add('active');
          selectedRisk = pill.dataset.risk || 'low';
          updateSummary();
        });
      });

      document.querySelector('.ai-asset-pill')?.addEventListener('click', (e) => {
        const btn = e.target.closest('.ai-asset-pill__item');
        const key = btn?.dataset.popover || btn?.dataset.market;
        if (!btn || !key) return;
        e.preventDefault();
        e.stopPropagation();
        if (!popover || !popoverBody || !POPOVER_HTML[key]) return;
        popoverBody.innerHTML = POPOVER_HTML[key];
        popover.hidden = false;
        const r = btn.getBoundingClientRect();
        const w = Math.min(440, window.innerWidth - 32);
        const left = Math.min(window.innerWidth - 16 - w, Math.max(16, r.left + r.width / 2 - w / 2));
        const top = Math.min(window.innerHeight - 24 - 120, r.bottom + 10);
        popover.style.width = w + 'px';
        popover.style.left = left + 'px';
        popover.style.top = top + 'px';

        requestAnimationFrame(() => {
          const pr = popover.getBoundingClientRect();
          const btnCenter = r.left + r.width / 2;
          const arrowX = Math.max(20, Math.min(pr.width - 20, btnCenter - pr.left));
          popover.style.setProperty('--ai-popover-arrow-left', arrowX + 'px');
        });
      });

      function closeMarketPopover() {
        if (popover) popover.hidden = true;
      }
      if (popoverClose && popover) {
        popoverClose.addEventListener('click', closeMarketPopover);
      }
      if (popoverOk && popover) {
        popoverOk.addEventListener('click', closeMarketPopover);
      }
      document.addEventListener('click', (e) => {
        if (!popover || popover.hidden) return;
        if (e.target.closest('#aiMarketPopover') || e.target.closest('.ai-asset-pill__item[data-market]')) return;
        popover.hidden = true;
      });

      if (investBtn) {
        investBtn.addEventListener('click', async () => {
          if (!termsChk || !termsChk.checked) {
            if (investMsg) {
              investMsg.textContent = 'Please agree to the terms before investing.';
              investMsg.classList.remove('success');
              investMsg.classList.add('error');
            }
            return;
          }

          const rangeVal = Number(rangeInput?.value) || 0;
          const cfg = riskConfig[selectedRisk] || riskConfig.low;
          const percent = Math.round(cfg.percent * 100);
          const profit = rangeVal * cfg.percent;
          const riskLabel = selectedRisk.charAt(0).toUpperCase() + selectedRisk.slice(1);

          const baseMsg =
            `My current balance is $${formatMoney2(currentBalance)}, ` +
            `I have selected investment amount $${formatMoney2(rangeVal)}. ` +
            `upto ${percent}% ($${formatMoney2(profit)}) with ${riskLabel} Risk.`;

          if (investMsg) {
            investMsg.textContent = 'Creating ticket...';
            investMsg.classList.remove('error', 'success');
          }
          investBtn.disabled = true;

          try {
            const res = await fetch('api/support/create_ticket.php', {
              method: 'POST',
              credentials: 'same-origin',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ text: baseMsg })
            });
            const data = await res.json();

            if (!res.ok || data.status === 'error') {
              if (investMsg) {
                investMsg.textContent = data.message || 'Failed to create ticket. Please try again.';
                investMsg.classList.remove('success');
                investMsg.classList.add('error');
              }
              return;
            }

            if (investMsg) {
              investMsg.textContent = 'Your ticket was created successfully.';
              investMsg.classList.remove('error');
              investMsg.classList.add('success');
            }
            setTimeout(() => {
              if (investMsg) {
                investMsg.textContent = '';
                investMsg.classList.remove('success');
              }
            }, 4000);

            if (termsChk) termsChk.checked = false;
            if (rangeInput) {
              rangeInput.value = '0';
              paintRangeTrack();
              positionTooltip();
              updateSummary();
            }
          } catch (err) {
            console.error(err);
            if (investMsg) {
              investMsg.textContent = 'Network error. Please try again.';
              investMsg.classList.remove('success');
              investMsg.classList.add('error');
            }
          } finally {
            investBtn.disabled = false;
          }
        });
      }

      if (termsLink && termsModal) {
        termsLink.addEventListener('click', (e) => {
          e.preventDefault();
          termsModal.classList.add('show');
        });
      }
      if (termsClose && termsModal) {
        termsClose.addEventListener('click', () => termsModal.classList.remove('show'));
      }
      if (termsModal) {
        termsModal.addEventListener('click', (e) => {
          if (e.target === termsModal) termsModal.classList.remove('show');
        });
      }
    }
  }
};

