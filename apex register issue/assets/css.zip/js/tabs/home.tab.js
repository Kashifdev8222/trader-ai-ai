// assets/js/tabs/home.tab.js — Dashboard (Figma layout)
window.CP_tabs = window.CP_tabs || {};
window.CP_state = window.CP_state || {};  

window.CP_tabs.home = function () {
  const view = document.querySelector('section.view[data-view="home"]');
  if (!view) return;

  const root = document.getElementById('home-view-root') || view;

  let allTxs = [];
  let txShowAll = false;
  let txPage = 1;
  const TX_PAGE_SIZE = 5;

  let newsItems = [];
  let newsExpanded = false;
  let newsPage = 1;
  const NEWS_PAGE_SIZE = 6;

  let allAccounts = [];
  let selectedTp = null;

  function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  function escapeAttr(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;');
  }

  /** Stock News API: Postman sample uses `news_url`; also support url, link, etc. */
  function newsArticleUrl(n) {
    if (!n || typeof n !== 'object') return '';
    const raw =
      n.news_url ||
      n.url ||
      n.link ||
      n.source_url ||
      n.article_url ||
      n.canonical_url ||
      '';
    if (typeof raw !== 'string') return '';
    const t = raw.trim();
    if (!t) return '';
    if (/^https?:\/\//i.test(t)) return t;
    if (/^\/\//.test(t)) return 'https:' + t;
    return '';
  }

  function formatMoney(n) {
    const v = Number(n);
    if (Number.isNaN(v)) return '$0';
    if (Math.abs(v) >= 1000) return '$' + (v / 1000).toFixed(1) + 'k';
    return '$' + v.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  }

  /** ISO 4217 code → symbol (Recent Transactions amount: show $ not "USD") */
  function currencySymbol(code) {
    if (!code) return '';
    const c = String(code).trim().toUpperCase();
    const map = {
      USD: '$',
      EUR: '€',
      GBP: '£',
      JPY: '¥',
      CNY: '¥',
      AUD: 'A$',
      CAD: 'C$',
      NZD: 'NZ$',
      INR: '₹',
      USDT: '₮',
      BTC: '₿',
      ETH: 'Ξ'
    };
    return map[c] || '';
  }

  function formatTxAmount(amount, currencyCode) {
    if (amount == null) return '—';
    const sym = currencySymbol(currencyCode);
    const raw = typeof amount === 'number' ? amount : parseFloat(String(amount).replace(/,/g, ''));
    if (Number.isNaN(raw)) {
      const c = (currencyCode || '').trim();
      return c ? `${amount} ${c}`.trim() : String(amount);
    }
    const neg = raw < 0;
    const abs = Math.abs(raw);
    const numStr = abs.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (!sym) {
      const c = (currencyCode || '').trim();
      return (neg ? '-' : '') + (c ? `${numStr} ${c}` : numStr);
    }
    const core = sym + numStr;
    return neg ? '-' + core : core;
  }

  function setGreetingName() {
    const el = document.getElementById('dashUserName');
    if (!el || !window.CP_USER) return;
    const u = window.CP_USER;
    const first = (u.firstName || '').trim();
    const last = (u.lastName || '').trim();
    const full = [first, last].filter(Boolean).join(' ') || u.email || 'John Doe';
    el.textContent = full;
  }

  function mockPl(seed) {
    const x = Math.sin(seed * 12.9898) * 43758.5453;
    return Math.round((x % 2000) - 800);
  }

  /* Sparkline stroke/fill: same hex as --cz-accent in dashboard.css */
  function sparklineSvg(seed) {
    const accent = '#7B61FF';
    const w = 280;
    const h = 56;
    const gid = 'g' + seed + '-' + Math.random().toString(36).slice(2, 8);
    const pts = [];
    for (let i = 0; i <= 12; i++) {
      const t = i / 12;
      const y = h / 2 + Math.sin(t * Math.PI * 2 + seed) * 16 + (seed % 7) * 2;
      pts.push(`${(t * w).toFixed(1)},${y.toFixed(1)}`);
    }
    const pathD = 'M' + pts.join(' L');
    return `
      <svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#7B61FF" stop-opacity="0.35"/>
            <stop offset="100%" stop-color="#7B61FF" stop-opacity="0"/>
          </linearGradient>
        </defs>
        <path d="${pathD} L ${w},${h} L 0,${h} Z" fill="url(#${gid})"/>
        <path d="${pathD}" fill="none" stroke="${accent}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`;
  }

  function renderAccountCards() {
    const rootEl = document.getElementById('dashAccountCards');
    if (!rootEl) return;

    const list = allAccounts.slice(0, 3);
    if (!list.length) {
      rootEl.innerHTML = '<div class="home-empty" style="grid-column:1/-1">No trading accounts.</div>';
      return;
    }

    rootEl.innerHTML = list
      .map((acc, i) => {
        const bal = parseFloat(acc.balance || 0);
        const id = acc.tpNumber || acc.accountNumber || '—';
        const pl = mockPl(i + (id || '').length);
        const equity = bal + pl * 0.001;
        const marginPct = 40 + (i % 4) * 5;
        const plCls = pl < 0 ? 'pl-neg' : 'pl-pos';
        const plSign = pl < 0 ? '' : '+';
        return `
        <article class="dash-acc-card">
          <div class="dash-acc-id">Account : #${escapeHtml(String(id))}</div>
          <div class="dash-acc-balance">${formatMoney(bal)}</div>
          <div class="dash-acc-meta">
            <span class="dash-acc-meta-item">
              <span class="dash-acc-meta-label">Equity :</span>
              <span class="dash-acc-meta-val">${formatMoney(equity)}</span>
            </span>
            <span class="dash-acc-meta-item ${plCls}">
              <span class="dash-acc-meta-label">P/L :</span>
              <span class="dash-acc-meta-val">${plSign}${formatMoney(Math.abs(pl))}</span>
            </span>
            <span class="dash-acc-meta-item">
              <span class="dash-acc-meta-label">Margin :</span>
              <span class="dash-acc-meta-val">${marginPct}%</span>
            </span>
          </div>
          <div class="dash-acc-chart">${sparklineSvg(i + 1)}</div>
        </article>`;
      })
      .join('');
  }

  /** Figma: arrow-in-box icon before transaction ID (unique clip id per row) */
  function txRowIdIcon(uid) {
    const clipId = 'txclip_' + String(uid).replace(/[^a-zA-Z0-9_-]/g, '_');
    return `<span class="dash-table-id-icon" aria-hidden="true"><svg width="23" height="23" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg" focusable="false">
<g clip-path="url(#${clipId})">
<path d="M22.9233 11.5877C22.7598 11.1738 22.4134 10.9801 21.8373 10.9814L18.5255 10.9916C18.0218 10.9916 17.9335 10.9162 17.9328 10.4329C17.9328 8.62032 17.9328 6.80777 17.9328 4.99521C17.9328 4.38347 17.7568 4.20063 17.1428 4.19995C15.2569 4.19995 13.371 4.19995 11.4851 4.19995V4.20675C9.57707 4.20675 7.66817 4.20675 5.75834 4.20675C5.19947 4.20675 5.01387 4.39639 5.01318 4.94355C5.01318 6.73255 5.01318 8.52244 5.01318 10.3133C5.01318 10.9175 4.9221 11.0079 4.28941 11.0086C3.18546 11.0086 2.08152 11.014 0.977572 11.0086C0.569802 11.0086 0.264837 11.1568 0.0888962 11.5272C-0.113264 11.9513 -0.0166689 12.4231 0.373162 12.7956C1.20112 13.5833 2.00562 14.3874 2.81771 15.1875C4.38531 16.7324 5.99155 18.2421 7.58468 19.7592C8.59295 20.7185 9.60743 21.6701 10.6281 22.614C11.176 23.1251 11.8011 23.1197 12.3385 22.614C13.5441 21.4811 14.7493 20.3483 15.954 19.2154C18.1874 17.1083 20.3628 14.9462 22.5562 12.8003C22.973 12.4081 23.0965 12.0268 22.9233 11.5877ZM18.5765 13.5201C16.7753 15.2665 14.9728 17.0111 13.1693 18.7539C12.6939 19.214 12.2116 19.6681 11.7493 20.1405C11.5761 20.3172 11.465 20.3383 11.2781 20.1575C9.01774 17.9661 6.7535 15.779 4.48536 13.5962C4.4427 13.5582 4.40324 13.5169 4.36737 13.4725C4.31631 13.4046 4.21489 13.3454 4.25629 13.2428C4.29769 13.1402 4.41015 13.1205 4.51778 13.1205C5.12702 13.1205 5.73557 13.1171 6.34481 13.1205C7.11274 13.1205 7.37976 12.8642 7.37976 12.1077C7.37976 10.3534 7.38735 8.59835 7.37493 6.84334C7.37493 6.59593 7.42254 6.5164 7.68749 6.5198C8.9515 6.53339 10.2155 6.52591 11.4823 6.52591V6.52116C12.7463 6.52116 14.0103 6.52659 15.2771 6.5164C15.5013 6.5164 15.5641 6.57485 15.5634 6.79712C15.5552 8.55213 15.5634 10.3065 15.5634 12.0615C15.5634 12.856 15.8139 13.1123 16.6301 13.1123H18.424C18.5503 13.1123 18.6931 13.098 18.7435 13.2482C18.7808 13.3835 18.6524 13.446 18.5758 13.5201H18.5765Z" fill="#7B61FF"/>
<path d="M11.4837 0C13.3453 0 15.2082 0 17.0725 0C17.7024 0 17.9398 0.238579 17.9391 0.863912C17.9391 1.09026 17.9439 1.3166 17.9391 1.54362C17.9246 1.97252 17.6969 2.20837 17.2636 2.2512C17.1947 2.25596 17.1256 2.25732 17.0566 2.25528C13.3308 2.25528 9.60704 2.25528 5.88537 2.25528C5.71272 2.26443 5.54022 2.23467 5.381 2.16827C5.22093 2.09215 5.07949 1.97863 5.05603 1.79715C4.9931 1.36002 4.99613 0.916132 5.065 0.479874C5.12226 0.151575 5.37824 0.00407809 5.79981 0.00407809C7.69676 0.00135925 9.59324 0.00135925 11.4893 0.00407809L11.4837 0Z" fill="#7B61FF"/>
</g>
<defs>
<clipPath id="${clipId}">
<rect width="23" height="23" fill="white"/>
</clipPath>
</defs>
</svg></span>`;
  }

  function statusBadge(status) {
    const s = (status || '').toLowerCase();
    let cls = 'dash-badge--default';
    if (s.includes('block')) cls = 'dash-badge--blocked';
    else if (s.includes('verif') || s.includes('complete') || s === 'approved') cls = 'dash-badge--verified';
    else if (s.includes('pend')) cls = 'dash-badge--pending';
    else if (s.includes('reject')) cls = 'dash-badge--rejected';
    return `<span class="dash-badge ${cls}">${escapeHtml(status || '—')}</span>`;
  }

  function renderTxPagination(total, page, pageSize) {
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const cur = Math.min(Math.max(1, page), pages);
    let html = '';
    html += `<button type="button" class="dash-page-btn dash-page-btn--arrow" ${cur <= 1 ? 'disabled' : ''} data-p="${cur - 1}" aria-label="Previous">&lt;</button>`;
    const maxNum = 5;
    let start = Math.max(1, cur - Math.floor(maxNum / 2));
    let end = Math.min(pages, start + maxNum - 1);
    if (end - start < maxNum - 1) start = Math.max(1, end - maxNum + 1);
    for (let p = start; p <= end; p++) {
      html += `<button type="button" class="dash-page-btn ${p === cur ? 'is-active' : ''}" data-p="${p}">${p}</button>`;
    }
    html += `<button type="button" class="dash-page-btn dash-page-btn--arrow" ${cur >= pages ? 'disabled' : ''} data-p="${cur + 1}" aria-label="Next">&gt;</button>`;
    return { html, pages, cur };
  }

  function attachPagination(el, handler) {
    if (!el) return;
    el.querySelectorAll('.dash-page-btn[data-p]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.disabled) return;
        const p = parseInt(btn.getAttribute('data-p'), 10);
        if (!Number.isNaN(p)) handler(p);
      });
    });
  }

  fetch('assets/views/home/home.html?v=' + Date.now())
    .then(r => r.text())
    .then(html => {
      root.innerHTML = html;
      setGreetingName();
      bindHomeEvents();
      loadHomeData();
    })
    .catch(err => {
      console.error('home template error', err);
      root.innerHTML = '<div class="text-danger p-3">Failed to load home view.</div>';
    });

  function bindHomeEvents() {
    document.getElementById('homeDepositBtn')?.addEventListener('click', () => {
      window.CP_showView && window.CP_showView('deposit');
    });
    document.getElementById('homeWithdrawBtn')?.addEventListener('click', () => {
      window.CP_showView && window.CP_showView('withdraw');
    });

    document.getElementById('homeTxViewAll')?.addEventListener('click', () => {
      txShowAll = !txShowAll;
      txPage = 1;
      renderTransactions();
    });

    document.getElementById('homeNewsMore')?.addEventListener('click', () => {
      newsExpanded = !newsExpanded;
      newsPage = 1;
      renderNews();
    });

    const tpSelected = document.getElementById('homeTpSelected');
    const tpDropdown = document.getElementById('homeTpDropdown');
    if (tpSelected && tpDropdown) {
      tpSelected.addEventListener('click', e => {
        e.stopPropagation();
        tpDropdown.classList.toggle('open');
      });
      document.addEventListener('click', e => {
        if (!tpSelected.contains(e.target) && !tpDropdown.contains(e.target)) {
          tpDropdown.classList.remove('open');
        }
      });
    }
  }

  async function loadHomeData() {
    await Promise.all([loadAccounts(), loadTransactions(), loadNews()]);
  }

  async function loadAccounts() {
    try {
      const res = await fetch('api/accounts/get_accounts.php');
      const data = await res.json();
      if (!res.ok || data.status === 'error') return;

      allAccounts = (data.data || []).filter(a => !a.isArchived);
      if (!allAccounts.length) {
        renderAccountCards();
        return;
      }

      const defaultAcc = allAccounts.find(a => !a.isDemoAccount) || allAccounts[0];
      selectedTp = defaultAcc.tpNumber;
      
      window.CP_state.accounts = allAccounts;
      window.CP_state.selectedTp = selectedTp;
      
      renderAccountsDropdown();
      updateSelectedAccountUI();
    } catch (e) {
      console.error('accounts fetch error', e);
    }
  }

  function renderAccountsDropdown() {
    const tpDropdown = document.getElementById('homeTpDropdown');
    if (!tpDropdown) return;
    tpDropdown.innerHTML = '';
    allAccounts.forEach(acc => {
      const item = document.createElement('div');
      item.className = 'home-tp-item';
      item.textContent = acc.tpNumber || '';
      if (acc.tpNumber === selectedTp) item.classList.add('active');
      item.addEventListener('click', () => {
        selectedTp = acc.tpNumber;
        tpDropdown.querySelectorAll('.home-tp-item').forEach(el => el.classList.remove('active'));
        item.classList.add('active');
        updateSelectedAccountUI();
        tpDropdown.classList.remove('open');
      });
      tpDropdown.appendChild(item);
    });
  }

  function updateSelectedAccountUI() {
    const tpText = document.getElementById('homeTpSelectedText');
    const acc = allAccounts.find(a => a.tpNumber === selectedTp) || allAccounts[0];
    if (!acc) return;
    if (tpText) tpText.textContent = acc.tpNumber || '—';

    window.CP_state.accounts = allAccounts;
    window.CP_state.selectedTp = selectedTp;

    renderTransactions();
    renderAccountCards();
  }

  async function loadTransactions() {
    const listEl = document.getElementById('homeTransactionsList');
    if (!listEl) return;
    try {
      const res = await fetch('api/accounts/get_transactions.php');
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        listEl.innerHTML = `<tr><td colspan="5" class="text-center home-empty">Failed to load transactions.</td></tr>`;
        return;
      }
      allTxs = (data.data || []).slice().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      txPage = 1;
      renderTransactions();
    } catch (e) {
      console.error('tx error', e);
      listEl.innerHTML = `<tr><td colspan="5" class="text-center home-empty">Failed to load transactions.</td></tr>`;
    }
  }

  function renderTransactions() {
    const listEl = document.getElementById('homeTransactionsList');
    const btn = document.getElementById('homeTxViewAll');
    const pagEl = document.getElementById('dashTxPagination');
    if (!listEl) return;

    let txs = allTxs.slice();
    if (!txShowAll) {
    if (selectedTp) {
      const filtered = txs.filter(t => {
          const tp = t.tpNumber || t.accountNumber || (t.account && t.account.tpNumber);
        return tp === selectedTp;
      });
        if (filtered.length) txs = filtered;
      }
    } else {
      txs = allTxs.slice();
    }

    if (!txs.length) {
      listEl.innerHTML = `<tr><td colspan="5" class="text-center home-empty">No transactions yet.</td></tr>`;
      if (pagEl) pagEl.innerHTML = '';
      if (btn) btn.textContent = 'View All';
      return;
    }

    const total = txs.length;
    const pageSize = TX_PAGE_SIZE;
    const pages = Math.max(1, Math.ceil(total / pageSize));
    txPage = Math.min(Math.max(1, txPage), pages);
    const start = (txPage - 1) * pageSize;
    const slice = txs.slice(start, start + pageSize);

    listEl.innerHTML = slice
      .map((tx, txIdx) => {
        const id = tx.id || tx.transactionId || tx.reference || '—';
        const iconUid = start + txIdx + '_' + String(id);
      const d = new Date(tx.createdAt);
        const dateStr = isNaN(d.getTime())
          ? '—'
          : d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
        const amt = formatTxAmount(tx.amount, tx.currency);
        /* API returns rejectReason (see clientzone/lead/account/transactions) */
        const reason = tx.rejectReason || tx.rejectionReason || tx.reason || tx.message || '—';
        const showReason = (tx.status || '').toLowerCase().includes('reject') ? reason : '—';
        return `
        <tr>
          <td>
            <span class="dash-table-id">${txRowIdIcon(iconUid)}<span class="dash-table-id-num">#${escapeHtml(String(id))}</span></span>
          </td>
          <td>${escapeHtml(dateStr)}</td>
          <td>${escapeHtml(amt)}</td>
          <td>${statusBadge(tx.status)}</td>
          <td class="${showReason === '—' ? 'dash-empty-cell' : ''}">${escapeHtml(showReason)}</td>
        </tr>`;
      })
      .join('');

    if (btn) btn.textContent = txShowAll ? 'Show less' : 'View All';

    if (pagEl) {
      if (pages > 1) {
        const { html } = renderTxPagination(total, txPage, pageSize);
        pagEl.innerHTML = html;
        attachPagination(pagEl, p => {
          txPage = p;
          renderTransactions();
        });
      } else {
        pagEl.innerHTML = '';
      }
    }
  }

  function timeAgo(dateStr) {
    const d = new Date(dateStr);
    if (isNaN(d)) return '';
    const diffMs = Date.now() - d.getTime();
    const mins = Math.round(diffMs / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + ' min ago';
    const hrs = Math.round(mins / 60);
    if (hrs < 24) return hrs + 'h ago';
    return Math.round(hrs / 24) + 'd ago';
  }

  async function loadNews() {
    const listEl = document.getElementById('homeNewsList');
    if (!listEl) return;
    try {
      const res = await fetch('api/news/latest.php');
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        listEl.innerHTML = '<div class="home-empty">Failed to load news.</div>';
        return;
      }
      newsItems = data.data || [];
      renderNews();
    } catch (e) {
      console.error('news error', e);
      listEl.innerHTML = '<div class="home-empty">Failed to load news.</div>';
    }
  }

  function renderNewsPagination(total, page, pageSize, containerId, onPage) {
    const el = document.getElementById(containerId);
    if (!el) return;
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const cur = Math.min(page, pages);
    let html = '';
    html += `<button type="button" class="dash-page-btn dash-page-btn--arrow" ${cur <= 1 ? 'disabled' : ''} data-np="${cur - 1}">&lt;</button>`;
    for (let p = 1; p <= pages; p++) {
      html += `<button type="button" class="dash-page-btn ${p === cur ? 'is-active' : ''}" data-np="${p}">${p}</button>`;
    }
    html += `<button type="button" class="dash-page-btn dash-page-btn--arrow" ${cur >= pages ? 'disabled' : ''} data-np="${cur + 1}">&gt;</button>`;
    el.innerHTML = html;
    el.querySelectorAll('.dash-page-btn[data-np]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.disabled) return;
        const p = parseInt(btn.getAttribute('data-np'), 10);
        if (!Number.isNaN(p)) onPage(p);
      });
    });
  }

  function renderNews() {
    const listEl = document.getElementById('homeNewsList');
    const titleEl = document.getElementById('homeNewsTitle');
    const moreBtn = document.getElementById('homeNewsMore');
    if (!listEl) return;

    if (!newsItems.length) {
      listEl.innerHTML = '<div class="home-empty">No news available.</div>';
      const pb = document.getElementById('dashNewsPaginationBottom');
      if (pb) pb.innerHTML = '';
      if (titleEl) titleEl.textContent = 'Latest News';
      if (moreBtn) moreBtn.textContent = 'View All';
      return;
    }

    const pool = newsExpanded ? newsItems : newsItems.slice(0, 12);
    const total = pool.length;
    const pages = Math.max(1, Math.ceil(total / NEWS_PAGE_SIZE));
    newsPage = Math.min(newsPage, pages);
    const start = (newsPage - 1) * NEWS_PAGE_SIZE;
    const itemsToShow = pool.slice(start, start + NEWS_PAGE_SIZE);

    listEl.innerHTML = itemsToShow
      .map(n => {
        const imgUrl = n.image_url || n.image || '';
        const title = n.title || '';
        const text = (n.text || '').substring(0, 220);
        const href = newsArticleUrl(n);
        const thumb = imgUrl
          ? `<div class="dash-news-thumb"><img src="${escapeHtml(imgUrl)}" alt=""></div>`
          : `<div class="dash-news-thumb" aria-hidden="true"></div>`;
        const body = `
          ${thumb}
          <div class="dash-news-body">
            <h3 class="dash-news-card-title">${escapeHtml(title)}</h3>
            <p class="dash-news-card-text">${escapeHtml(text)}${(n.text || '').length > 220 ? '…' : ''}</p>
          </div>`;
        const label = title.trim() || 'News article';
        if (href) {
          return `
        <a class="dash-news-card dash-news-card--link" href="${escapeAttr(href)}" target="_blank" rel="noopener noreferrer" aria-label="${escapeAttr(label)}">
          ${body}
        </a>`;
        }
        return `
        <article class="dash-news-card">
          ${body}
        </article>`;
      })
      .join('');

    const pagHandler = p => {
      newsPage = p;
      renderNews();
    };

    renderNewsPagination(total, newsPage, NEWS_PAGE_SIZE, 'dashNewsPaginationBottom', pagHandler);

    if (titleEl) titleEl.textContent = newsExpanded ? 'All News' : 'Latest News';
    if (moreBtn) moreBtn.textContent = newsExpanded ? '← Back' : 'View All';
  }
};
