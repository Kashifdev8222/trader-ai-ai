// assets/js/tabs/web-trader.tab.js — pick TP once, then embed https://trader.mic-market.com/auth/login?...&tpNumber=...
window.CP_tabs = window.CP_tabs || {};
window.CP_state = window.CP_state || {};
window.CP_onViewShow = window.CP_onViewShow || {};

window.CP_tabs['web-trader'] = function () {
  const section = document.querySelector('section.view[data-view="web-trader"]');
  if (!section) return;

  const root = document.getElementById('web-trader-view-root') || section;

  function loadHtml() {
    if (root.querySelector('.wt-root')) {
      initWebTrader();
      return;
    }
    const url =
      typeof window.CP_fetchView === 'function'
        ? window.CP_fetchView('assets/views/web-trader/web-trader.html')
        : fetch('assets/views/web-trader/web-trader.html?v=' + Date.now(), { credentials: 'same-origin' }).then(
            (r) => {
              if (!r.ok) throw new Error('HTTP ' + r.status);
              return r.text();
            }
          );

    Promise.resolve(url)
      .then((html) => {
        if (typeof html === 'string') {
          root.innerHTML = html;
          initWebTrader();
        }
      })
      .catch((err) => {
        console.error('web-trader template error', err);
        root.innerHTML = '<div class="text-danger p-3">Failed to load Web Trader view.</div>';
      });
  }

  loadHtml();

  function initWebTrader() {
    const gate = document.getElementById('wtGate');
    const trader = document.getElementById('wtTrader');
    const select = document.getElementById('wtAccountSelect');
    const errEl = document.getElementById('wtGateError');
    const continueBtn = document.getElementById('wtContinueBtn');
    const status = document.getElementById('wtStatus');
    const frame = document.getElementById('wtFrame');

    if (!gate || !trader || !select || !frame) return;

    function showError(msg) {
      if (!errEl) return;
      errEl.textContent = msg || '';
      errEl.hidden = !msg;
    }

    function formatOptionLabel(acc) {
      const tp = acc.tpNumber != null && acc.tpNumber !== '' ? String(acc.tpNumber) : '';
      const name = (acc.name || '').trim() || 'Account';
      if (tp) return tp + ' (' + name + ')';
      return name;
    }

    /**
     * Loads the trader login page with session email/password and the selected tpNumber.
     * Cache-bust so the browser does not reuse a stale iframe document.
     */
    function showTrader(loginUrl) {
      gate.hidden = true;
      trader.hidden = false;
      const sep = loginUrl.indexOf('?') >= 0 ? '&' : '?';
      const url = loginUrl + sep + '_wt=' + Date.now();
      if (status) status.textContent = 'Loading Web Trader…';
      frame.src = url;
    }

    frame.addEventListener('load', () => {
      if (status && !trader.hidden) status.textContent = '';
    });

    async function loadAccounts() {
      select.innerHTML = '<option value="">Loading…</option>';
      select.disabled = true;
      showError('');

      try {
        const res = await fetch('api/accounts/get_accounts.php', { credentials: 'same-origin' });
        const json = await res.json();
        if (!res.ok || json.status === 'error') {
          select.innerHTML = '<option value="">No accounts</option>';
          showError(json.message || 'Could not load accounts.');
          return;
        }

        const list = (json.data || []).filter((a) => !a.isArchived);
        if (!list.length) {
          select.innerHTML = '<option value="">No trading accounts</option>';
          showError('No accounts found. Open Trading Account to add one.');
          return;
        }

        const frag = document.createDocumentFragment();
        list.forEach((acc) => {
          const tp = acc.tpNumber != null && acc.tpNumber !== '' ? String(acc.tpNumber) : '';
          if (!tp) return;
          const opt = document.createElement('option');
          opt.value = tp;
          opt.textContent = formatOptionLabel(acc);
          frag.appendChild(opt);
        });

        select.innerHTML = '';
        select.appendChild(frag);

        if (!select.options.length) {
          select.innerHTML = '<option value="">No TP numbers</option>';
          showError('Accounts have no TP number.');
          return;
        }

        const pref = window.CP_state?.selectedTp;
        if (pref) {
          const match = Array.from(select.options).find((o) => o.value === String(pref));
          if (match) select.value = match.value;
        }
        select.disabled = false;
      } catch (e) {
        console.error(e);
        select.innerHTML = '<option value="">Error</option>';
        showError('Network error loading accounts.');
      }
    }

    async function buildTraderUrl(tpNumber) {
      const q = tpNumber ? '?tpNumber=' + encodeURIComponent(tpNumber) : '';
      const res = await fetch('api/webtrader/url.php' + q, { credentials: 'same-origin' });
      const json = await res.json();
      const payload = json.data && typeof json.data === 'object' ? json.data : {};

      if (json.status === 'error') {
        throw new Error(json.message || 'Could not build Web Trader URL.');
      }

      if (payload.hasCredentials === false) {
        throw new Error(
          payload.message || 'Session has no stored password for Web Trader. Please log out and sign in again.'
        );
      }

      const url = payload.url;
      if (!url) {
        throw new Error('Missing Web Trader URL.');
      }

      return url;
    }

    async function openTraderForTp(tp) {
      const t = String(tp || '').trim();
      if (!t) {
        showError('Please choose an account.');
        return;
      }
      showError('');
      if (continueBtn) continueBtn.disabled = true;

      try {
        const loginUrl = await buildTraderUrl(t);
        window.CP_state = window.CP_state || {};
        window.CP_state.selectedTp = t;
        if (select) select.value = t;
        showTrader(loginUrl);
      } catch (e) {
        console.error(e);
        const msg = e.message || 'Failed to open Web Trader.';
        showError(msg);
        if (status) status.textContent = msg;
      } finally {
        if (continueBtn) continueBtn.disabled = false;
      }
    }

    continueBtn?.addEventListener('click', () => openTraderForTp(select.value?.trim()));

    loadAccounts();

    window.CP_onViewShow['web-trader'] = function () {
      loadAccounts();
    };
  }
};
