/* ===== Preloader ===== */
const preloader = document.getElementById('preloader');
const showPreloader = () => preloader?.classList.remove('d-none');
const hidePreloader = () => preloader?.classList.add('d-none');

/* ===== Views (Login / Register / Forgot) ===== */
const loginView = document.getElementById('loginView');
const registerView = document.getElementById('registerView');
const forgotView = document.getElementById('forgotView');

function showLogin() {
  registerView?.classList.remove('show');
  forgotView?.classList.remove('show');
  setTimeout(() => { loginView?.classList.add('show'); }, 10);
}

function showRegister() {
  loginView?.classList.remove('show');
  forgotView?.classList.remove('show');
  setTimeout(() => { registerView?.classList.add('show'); }, 10);
}

function showForgot() {
  loginView?.classList.remove('show');
  registerView?.classList.remove('show');
  setTimeout(() => { forgotView?.classList.add('show'); }, 10);
}

/* ===== DOM READY ===== */
document.addEventListener('DOMContentLoaded', () => {
  const goRegister = document.getElementById('goRegister');
  const goLogin = document.getElementById('goLogin');
  const goForgot = document.getElementById('goForgot');
  const backToLogin = document.getElementById('backToLogin');

  goRegister?.addEventListener('click', (e) => { e.preventDefault(); showRegister(); });
  goLogin?.addEventListener('click', (e) => { e.preventDefault(); showLogin(); });
  goForgot?.addEventListener('click', (e) => { e.preventDefault(); showForgot(); });
  backToLogin?.addEventListener('click', (e) => { e.preventDefault(); showLogin(); });

  /* Splash screen → fade out then reveal auth wrapper */
  const splash = document.getElementById('splashScreen');
  const authWrapper = document.querySelector('.auth-wrapper');

  if (splash && authWrapper) {
    // Show the login wrapper immediately (behind splash)
    authWrapper.classList.remove('d-none');
    authWrapper.classList.add('show');

    // Now just fade splash out
    setTimeout(() => {
      splash.classList.add('fade-out');
      setTimeout(() => {
        splash.style.display = 'none';
      }, 600); // fade time matches CSS
    }, 1000); // how long splash stays before fading out
  }
});

/* ===== Password Show/Hide with eye icon swap ===== */
function makeShowHide(btnId, inputId) {
  const btn = document.getElementById(btnId);
  const input = document.getElementById(inputId);
  if (!btn || !input) return;

  btn.addEventListener('click', () => {
    const to = input.type === 'password' ? 'text' : 'password';
    input.type = to;

    const icon = btn.querySelector('i');
    if (icon) {
      icon.classList.toggle('bi-eye');
      icon.classList.toggle('bi-eye-slash');
    }
  });
}
makeShowHide('toggleLoginPwd', 'loginPassword');
makeShowHide('toggleRegPwd', 'regPassword');

/* ===== LOGIN submit -> api/auth/login.php ===== */
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value.trim();
  const errorBox = document.getElementById('loginError');

  if (!email || !password) {
    errorBox.textContent = 'Please fill in both fields.';
    setTimeout(() => { errorBox.textContent = ''; }, 3000); // Hide the error after 3 seconds
    return;
  }

  errorBox.textContent = '';
  showPreloader();

  try {
    const res = await fetch('api/auth/login.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok || data.status === 'error') {
      errorBox.textContent = data.message || 'Login failed.';
      hidePreloader();
      setTimeout(() => { errorBox.textContent = ''; }, 3000); // Hide the error after 3 seconds
      return;
    }

     window.location.href = '/dashboard';
  } catch (err) {
    errorBox.textContent = 'Network error. Try again.';
    setTimeout(() => { errorBox.textContent = ''; }, 3000); // Hide the error after 3 seconds
  } finally {
    hidePreloader();
  }
});

/* ===== REGISTER: phone init + validation + submit ===== */
let iti; // intl-tel-input instance
(function initRegister() {
  const phoneEl = document.getElementById('phone');
  if (!phoneEl) return;

  // country by IP (fallback gb)
  fetch('https://ipinfo.io/json?token=5a8c00f1abba8d')
    .then(r => r.json())
    .then(d => setupPhone((d && d.country) ? d.country.toLowerCase() : 'gb'))
    .catch(() => setupPhone('gb'));

  function setupPhone(cc) {
    try {
      iti = window.intlTelInput(phoneEl, {
        initialCountry: cc,
        separateDialCode: true,
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
      });
    } catch (e) { console.error(e); }
  }

  // helper: validate phone with intl-tel-input
  function validatePhone() {
    const phoneErr = document.getElementById('phoneError');
    phoneErr.textContent = '';
    phoneEl.classList.remove('is-invalid');

    if (!iti) return true; // if init failed, don't block

    if (!iti.isValidNumber()) {
      const code = iti.getValidationError();
      const map = {
        0: 'Invalid phone number',
        1: 'Invalid country code',
        2: 'Number is too short',
        3: 'Number is too long',
        4: 'Invalid phone number'
      };
      phoneErr.textContent = map[code] || 'Invalid phone number';
      phoneEl.classList.add('is-invalid');
      return false;
    }
    return true;
  }

  // live-validate on blur/change
  ['blur', 'change', 'keyup'].forEach(ev => phoneEl.addEventListener(ev, validatePhone));

  // submit
  document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const msgBox = document.getElementById('registerMsg');
    const phoneOk = validatePhone();

    const payload = {
      fullName: document.getElementById('fullName').value.trim(),
      email: document.getElementById('regEmail').value.trim(),
      password: document.getElementById('regPassword').value,
      birthDate: document.getElementById('birthDate').value
        ? new Date(document.getElementById('birthDate').value).toISOString()
        : undefined,
      phone: (window.intlTelInput && iti) ? iti.getNumber() : phoneEl.value.trim()
    };

    if (!payload.fullName || !payload.email || !payload.password || !payload.phone) {
      msgBox.className = 'tiny mt-2 text-center text-danger';
      msgBox.textContent = 'Please fill in all required fields.';
      setTimeout(() => { msgBox.textContent = ''; }, 3000); // Hide the error after 3 seconds
      return;
    }
    if (!phoneOk) {
      msgBox.className = 'tiny mt-2 text-center text-danger';
      msgBox.textContent = 'Please enter a valid phone number.';
      setTimeout(() => { msgBox.textContent = ''; }, 3000); // Hide the error after 3 seconds
      return;
    }

    msgBox.textContent = '';
    showPreloader();

    try {
      const res = await fetch('api/leads/register.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok || data.status === 'error') {
        msgBox.className = 'tiny mt-2 text-center text-danger';
        msgBox.textContent = data.message || 'Registration failed.';
        hidePreloader();
        setTimeout(() => { msgBox.textContent = ''; }, 3000); // Hide the error after 3 seconds
        return;
      }

      msgBox.className = 'tiny mt-2 text-center text-success';
      msgBox.textContent = 'Registration successful! Redirecting to login...';
      setTimeout(() => { showLogin(); msgBox.textContent = ''; }, 1500);
    } catch (err) {
      msgBox.className = 'tiny mt-2 text-center text-danger';
      msgBox.textContent = 'Network error. Try again.';
      setTimeout(() => { msgBox.textContent = ''; }, 3000); // Hide the error after 3 seconds
    } finally {
      hidePreloader();
    }
  });
})();

/* ===== FORGOT PASSWORD ===== */
document.getElementById('forgotForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const emailEl = document.getElementById('forgotEmail');
  const msgBox = document.getElementById('forgotMsg');

  const email = emailEl.value.trim();
  msgBox.textContent = '';
  if (!email) {
    msgBox.className = 'tiny mt-2 text-center text-danger';
    msgBox.textContent = 'Please enter your email.';
    emailEl.focus();
    setTimeout(() => { msgBox.textContent = ''; }, 3000); // Hide the error after 3 seconds
    return;
  }

  showPreloader();
  try {
    const res = await fetch('api/auth/forgotpass.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    const data = await res.json();
    if (!res.ok || data.status === 'error') {
      msgBox.className = 'tiny mt-2 text-center text-danger';
      msgBox.textContent = data.message || 'Error sending reset link.';
      hidePreloader();
      setTimeout(() => { msgBox.textContent = ''; }, 3000); // Hide the error after 3 seconds
      return;
    }

    msgBox.className = 'tiny mt-2 text-center text-success';
    msgBox.textContent = 'Password reset email sent! Returning to login...';
    setTimeout(() => { showLogin(); msgBox.textContent = ''; emailEl.value = ''; }, 1500);
  } catch (err) {
    msgBox.className = 'tiny mt-2 text-center text-danger';
    msgBox.textContent = 'Network error. Please try again.';
    setTimeout(() => { msgBox.textContent = ''; }, 3000); // Hide the error after 3 seconds
  } finally {
    hidePreloader();
  }
});
