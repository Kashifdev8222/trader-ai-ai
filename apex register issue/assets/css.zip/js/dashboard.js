/* assets/js/dashboard.js
   Global shell: login guard, sidebar (desktop+mobile),
   tab switching + lazy tab init.
*/

/**
 * Full-screen preloader:
 * - Boot: visible in HTML until hideBoot() after first route is ready.
 * - After boot: only while a tab’s .js bundle is downloading (not during routine API calls —
 *   a global fetch hook would wait for every parallel request and felt “stuck”).
 * Use CP_preloader.wrap(promise) for a specific long action if needed.
 */
window.CP_preloader = (function () {
  let depth = 0;
  let showTimer = null;
  let bootComplete = false;
  let overlayShown = false;
  const DELAY_MS = 50;
  const MIN_VISIBLE_MS = 0;
  let shownAt = 0;

  function getEl() {
    return document.getElementById('cpPreloader');
  }

  function showOverlayNow() {
    const el = getEl();
    if (!el) return;
    el.classList.add('is-visible');
    el.setAttribute('aria-busy', 'true');
    shownAt = Date.now();
    overlayShown = true;
  }

  function hideOverlayNow() {
    const el = getEl();
    if (!el) return;
    const finish = () => {
      el.classList.remove('is-visible');
      el.setAttribute('aria-busy', 'false');
      overlayShown = false;
      shownAt = 0;
    };
    if (!overlayShown || !shownAt) {
      finish();
      return;
    }
    const wait = Math.max(0, MIN_VISIBLE_MS - (Date.now() - shownAt));
    if (wait <= 0) finish();
    else setTimeout(finish, wait);
  }

  function armShowTimer() {
    clearTimeout(showTimer);
    showTimer = setTimeout(() => {
      showTimer = null;
      if (depth > 0) showOverlayNow();
    }, DELAY_MS);
  }

  function enter() {
    if (!bootComplete) return;
    depth++;
    if (depth === 1) armShowTimer();
  }

  function leave() {
    if (!bootComplete) return;
    depth = Math.max(0, depth - 1);
    if (depth > 0) return;
    clearTimeout(showTimer);
    showTimer = null;
    if (!overlayShown) return;
    hideOverlayNow();
  }

  function hideBoot() {
    bootComplete = true;
    clearTimeout(showTimer);
    showTimer = null;
    depth = 0;
    const el = getEl();
    if (el) {
      el.classList.remove('is-visible');
      el.setAttribute('aria-busy', 'false');
    }
    overlayShown = false;
    shownAt = 0;
  }

  function wrap(promise) {
    enter();
    return Promise.resolve(promise).finally(() => leave());
  }

  return {
    enter,
    leave,
    hideBoot,
    wrap,
    get bootComplete() {
      return bootComplete;
    }
  };
})();

/**
 * Expired or invalid API token: upstream returns 401 → send user to login with a clean session.
 * Excludes change_password.php so a wrong current password can show an error without logging out.
 */
(function () {
  const origFetch = window.fetch.bind(window);
  const SKIP_401_REDIRECT = /change_password\.php/i;
  window.fetch = function (input, init) {
    return origFetch(input, init).then((res) => {
      if (res.status !== 401) return res;
      let urlStr = '';
      try {
        if (typeof input === 'string') urlStr = input;
        else if (input && typeof input.url === 'string') urlStr = input.url;
      } catch (e) {
        /* ignore */
      }
      let abs;
      try {
        abs = new URL(urlStr || '', window.location.href);
      } catch (e2) {
        return res;
      }
      if (abs.origin !== window.location.origin) return res;
      const path = abs.pathname || '';
      if (path.indexOf('/api/') === -1) return res;
      if (SKIP_401_REDIRECT.test(path)) return res;
      window.location.assign('/logout.php');
      return res;
    });
  };
})();

document.addEventListener('DOMContentLoaded', async () => {
  if (!window.CP_USER || !window.CP_USER.userId) {
    window.location.assign('/');
    return;
  }

  // Prefill change-password email
  const passEmailEl = document.getElementById('passEmail');
  if (passEmailEl) passEmailEl.value = CP_USER.email || '';

  function syncProfileDropdown() {
    const u = window.CP_USER;
    if (!u) return;
    const f = [u.firstName, u.lastName].map((s) => String(s || '').trim()).filter(Boolean).join(' ');
    const nameEl = document.getElementById('cpProfileName');
    const emailEl = document.getElementById('cpProfileEmail');
    if (nameEl) nameEl.textContent = f || '—';
    if (emailEl) emailEl.textContent = String(u.email || '').trim() || '—';
  }
  syncProfileDropdown();

  document.getElementById('cpOpenChangePassword')?.addEventListener('click', () => {
    const profileBtn = document.getElementById('cpProfileBtn');
    const dd = profileBtn && bootstrap.Dropdown.getInstance(profileBtn);
    dd?.hide();
    const modalEl = document.getElementById('changePassModal');
    if (modalEl && typeof bootstrap !== 'undefined') {
      bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }
  });

  // Show/Hide password in modal
  document.querySelectorAll('[data-toggle="show"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.querySelector(btn.getAttribute('data-target'));
      if (!target) return;
      const to = target.type === 'password' ? 'text' : 'password';
      target.type = to;
      btn.textContent = (to === 'text') ? 'Hide' : 'Show';
    });
  });

  const sidebar  = document.getElementById('sidebar');
  const backdrop = document.querySelector('.sidebar-backdrop');
  const closeBtn = document.querySelector('.close-sidebar');
  const toggleBtn = document.getElementById('sidebarToggle');

  sidebar?.classList.remove('collapsed');

  /**
   * Token can expire after hours while user keeps the tab open — no fetch runs, so they stay on a dead page.
   * Ping CRM via session_ping; 401/403 is handled by the fetch wrapper → logout → login.
   */
  function sessionPing() {
    fetch('api/auth/session_ping.php', { credentials: 'same-origin' }).catch(() => {});
  }
  let sessionPingDebounce = null;
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    clearTimeout(sessionPingDebounce);
    sessionPingDebounce = setTimeout(sessionPing, 400);
  });
  setInterval(sessionPing, 4 * 60 * 1000);
  setTimeout(sessionPing, 10000);

  async function loadNotifications() {
    const badge = document.getElementById('cpNotifyBadge');
    const listEl = document.getElementById('cpNotifyList');
    const emptyEl = document.getElementById('cpNotifyEmpty');
    if (!listEl) return;
    try {
      const res = await fetch('api/notifications/list.php', { credentials: 'same-origin' });
      const data = await res.json();
      if (!data || data.ok === false) return;
      const unread = Math.max(0, parseInt(String(data.unread ?? 0), 10) || 0);
      const items = Array.isArray(data.items) ? data.items : [];
      if (badge) {
        if (unread > 0) {
          badge.hidden = false;
          badge.textContent = unread > 99 ? '99+' : String(unread);
        } else {
          badge.hidden = true;
          badge.textContent = '';
        }
      }
      const existing = listEl.querySelectorAll('.cp-notify-item');
      existing.forEach(n => n.remove());
      if (emptyEl) {
        emptyEl.classList.toggle('is-hidden', items.length > 0);
      }
      items.forEach((raw) => {
        const title = typeof raw.title === 'string' ? raw.title : 'Notification';
        const body = typeof raw.body === 'string' ? raw.body : '';
        const at = typeof raw.at === 'string' ? raw.at : '';
        const row = document.createElement('div');
        row.className = 'cp-notify-item';
        row.innerHTML =
          `<div class="cp-notify-item-title">${escapeHtml(title)}</div>` +
          (body ? `<div class="small text-muted">${escapeHtml(body)}</div>` : '') +
          (at ? `<div class="cp-notify-item-meta">${escapeHtml(at)}</div>` : '');
        listEl.appendChild(row);
      });
    } catch {
      /* ignore — badge stays hidden */
    }
  }

  function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  loadNotifications();
  setInterval(loadNotifications, 60000);
  window.CP_refreshNotifications = loadNotifications;

  const DESKTOP_BREAKPOINT = 992;

  function isMobile() {
    return window.innerWidth < DESKTOP_BREAKPOINT;
  }

  // restore collapsed state on desktop
  const savedSidebar = localStorage.getItem('cp_sidebar');
  if (savedSidebar === 'collapsed' && !isMobile()) {
    sidebar?.classList.add('collapsed');
  }

  // === Mobile sidebar overlay helpers ===
  function openMobile() {
    document.body.classList.add('sidebar-open');
    sidebar?.classList.add('show');
  }
  function closeMobile() {
    document.body.classList.remove('sidebar-open');
    sidebar?.classList.remove('show');
  }

  // Single hamburger button controls both desktop collapse and mobile overlay
  toggleBtn?.addEventListener('click', e => {
    e.preventDefault();
    if (!isMobile()) return;
    if (sidebar?.classList.contains('show')) {
      closeMobile();
    } else {
      openMobile();
    }
  });

  backdrop?.addEventListener('click', closeMobile);
  closeBtn?.addEventListener('click', closeMobile);
  window.addEventListener('resize', () => {
    if (!isMobile()) {
      closeMobile();
      sidebar?.classList.remove('collapsed');
    }
  });

  // Change Password submit
  const passMsg = document.getElementById('passMsg');
  document.getElementById('changePassForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const email = passEmailEl?.value?.trim();
    const password = document.getElementById('oldPass').value;
    const newPassword  = document.getElementById('newPass').value;
    if (!email || !password || !newPassword){
      passMsg.textContent = 'Please fill all fields.';
      passMsg.className = 'small mt-2 text-danger text-center';
      return;
    }
    passMsg.textContent = 'Updating...';
    passMsg.className = 'small mt-2 text-muted text-center';

    try{
      const res = await fetch('api/auth/change_password.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ email, password, newPassword })
      });
      const data = await res.json();
      if (!res.ok || data.status === 'error'){
        passMsg.textContent = data.message || 'Error changing password.';
        passMsg.className = 'small mt-2 text-danger text-center';
        return;
      }
      passMsg.textContent = 'Password changed successfully!';
      passMsg.className = 'small mt-2 text-success text-center';
      e.target.reset();
      passEmailEl.value = email;
      setTimeout(() => {
        const m = bootstrap.Modal.getInstance('#changePassModal') || new bootstrap.Modal('#changePassModal');
        m.hide();
        passMsg.textContent = '';
      }, 1200);
    }catch{
      passMsg.textContent = 'Network error. Try again.';
      passMsg.className = 'small mt-2 text-danger text-center';
    }
  });

  // -------- Tab switching + lazy per-tab init --------
  /** Only main content tab panes (avoids stray `.view` elsewhere in DOM). */
  const views = document.querySelectorAll('#mainContent section.view');

  window.CP_tabLoaded  = window.CP_tabLoaded || {};
  window.CP_tabs       = window.CP_tabs || {};
  window.CP_onViewShow = window.CP_onViewShow || {};   // <-- NEW


  async function lazyInitTab(name){
    const isAnalysis = typeof name === 'string' && name.indexOf('analysis-') === 0;
    const loadKey = isAnalysis ? 'analysis-embed' : name;

    if (window.CP_tabLoaded[loadKey]) {
      if (typeof window.CP_tabs[name] === 'function' && !window.CP_tabs[name]._inited){
        window.CP_tabs[name]();
        window.CP_tabs[name]._inited = true;
      }
      return;
    }

    // Explicit mapping to avoid path/name mismatches
   const tabScriptMap = {
      home:        'assets/js/tabs/home.tab.js',
      'trading-account': 'assets/js/tabs/trading-account.tab.js',
      trading:     'assets/js/tabs/trading.tab.js',
      deposit:     'assets/js/tabs/deposit.tab.js',
      withdraw:    'assets/js/tabs/withdraw.tab.js',   // FIXED
      verification:'assets/js/tabs/verification.tab.js',
      'settings-profile': 'assets/js/tabs/settings-profile.tab.js',
      support:     'assets/js/tabs/support.tab.js',
      'ai-setting':'assets/js/tabs/ai-setting.tab.js',
      'web-trader':'assets/js/tabs/web-trader.tab.js',
      settings:    'assets/js/tabs/settings.tab.js',
      help:        'assets/js/tabs/help.tab.js',
    };
    let url = tabScriptMap[name];
    if (!url && isAnalysis) url = 'assets/js/tabs/analysis-embed.tab.js';
    if (!url) url = `assets/js/tabs/${name}.tab.js`;
    console.log('[lazyInitTab] loading:', url);

    try {
      await new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = url + '?v=' + Date.now();   // cache-bust while testing
        s.async = true;
        s.onload = resolve;
        s.onerror = reject;
        document.head.appendChild(s);
      });
      window.CP_tabLoaded[loadKey] = true;
      if (typeof window.CP_tabs[name] === 'function' && !window.CP_tabs[name]._inited) {
        window.CP_tabs[name]();
        window.CP_tabs[name]._inited = true;
      }
    } catch (err) {
      console.error('[lazyInitTab] failed to load', url, err);
      const view = document.querySelector(`section.view[data-view="${name}"]`);
      if (view) {
        view.innerHTML =
          `<div class="text-danger p-3">Failed to load <code>${url}</code> (404). Place the file there or update tabScriptMap.</div>`;
      }
    }
  }

  async function showView(name) {
    const target = String(name || '').trim();
    const scriptLoadKey =
      typeof target === 'string' && target.indexOf('analysis-') === 0 ? 'analysis-embed' : target;
    const willLoadTabScript = !window.CP_tabLoaded[scriptLoadKey];
    if (willLoadTabScript && window.CP_preloader?.bootComplete) {
      window.CP_preloader.enter();
    }
    try {
      // 1) show/hide sections
      views.forEach((v) => v.classList.toggle('show', v.getAttribute('data-view') === target));

      // 2) chrome title = whichever section is actually visible (source of truth)
      syncChromeTitleFromDom();

      // 3) ensure tab script is loaded & initialised
      await lazyInitTab(target);

      // Tab scripts can touch DOM; keep header in sync
      syncChromeTitleFromDom();

      // 4) run "on show" hook EVERY time this view is opened
      if (window.CP_onViewShow && typeof window.CP_onViewShow[target] === 'function') {
        window.CP_onViewShow[target]();
      }

      syncChromeTitleFromDom();
    } finally {
      if (willLoadTabScript && window.CP_preloader?.bootComplete) {
        window.CP_preloader.leave();
      }
    }
  }
  // make it usable from tab scripts (home, etc)
  window.CP_showView = showView;

  /** Human-readable title for each `data-view` value (keys must be lowercase). */
  const CP_TAB_TITLES = {
    home: 'Dashboard',
    'trading-account': 'Trading Account',
    deposit: 'Deposit',
    withdraw: 'Withdrawal',
    verification: 'Verification',
    'analysis-technical': 'Technical Analysis',
    'analysis-calendar': 'Economic Calendar',
    'analysis-news': 'News',
    'ai-setting': 'AI Settings',
    'web-trader': 'Web Trader',
    'settings-profile': 'Profile',
    'settings-questionnaire': 'Questionnaire',
    support: 'Support',
    help: 'Help',
  };

  function syncChromeTitleFromDom() {
    const activeTabName = document.getElementById('activeTabName');
    if (!activeTabName) return;
    const shown = document.querySelector('#mainContent section.view.show');
    const raw = (shown && shown.getAttribute('data-view')) || 'home';
    const key = String(raw).trim().toLowerCase();
    activeTabName.textContent = CP_TAB_TITLES[key] || CP_TAB_TITLES.home;
  }

  window.CP_syncChromeTitle = syncChromeTitleFromDom;

  function activateSidebarItem(item) {
    // remove all previous active states
    document
      .querySelectorAll('.menu-item.active, .submenu-item.active')
      .forEach(el => el.classList.remove('active'));

    if (item.classList.contains('submenu-item')) {
      // make submenu active + keep its group open
      item.classList.add('active');
      const parent = item.closest('.menu-item.has-sub');
      parent?.classList.add('open');
    } else {
      // normal (non-dropdown) item
      item.classList.add('active');

      // close dropdown groups that have no active child
      document.querySelectorAll('.menu-item.has-sub').forEach(group => {
        if (!group.querySelector('.submenu-item.active')) {
          group.classList.remove('open');
        }
      });
    }
  }

  // Sidebar click handling: open dropdowns + activate items
  sidebar?.addEventListener('click', e => {
    const isCollapsedDesktop = !isMobile() && sidebar?.classList.contains('collapsed');

    const groupMain = e.target.closest('.menu-main');
    const groupItem = groupMain?.closest('.menu-item.has-sub');

    // Click on group header (Analysis / Settings)
    if (groupItem && !e.target.closest('.submenu')) {
      if (isCollapsedDesktop) {
        // collapsed desktop: go directly to first submenu item
        const firstSub = groupItem.querySelector('.submenu-item');
        if (firstSub) {
          const viewName = firstSub.dataset.view;
          activateSidebarItem(firstSub);
          showView(viewName);
        }
      } else {
        // expanded: just open/close dropdown, do NOT change active item
        groupItem.classList.toggle('open');
      }
      return; // stop further handling for this click
    }

    // Click on real items (Home, Help, submenu items, etc.)
    const item = e.target.closest('[data-view]');
    if (!item) return;

    const viewName = item.getAttribute('data-view') || item.dataset.view;
    if (!viewName) return;

    activateSidebarItem(item);
    showView(viewName);

    if (isMobile()) closeMobile();
  });



  // Initial tab: Home
  const initialActive =
    sidebar?.querySelector('[data-view].active') ||
    sidebar?.querySelector('[data-view="home"]');

  const initialView = initialActive?.dataset.view || 'home';
  if (initialActive) initialActive.classList.add('active');
  try {
    await showView(initialView);
  } finally {
    if (window.CP_preloader) window.CP_preloader.hideBoot();
  }
});

