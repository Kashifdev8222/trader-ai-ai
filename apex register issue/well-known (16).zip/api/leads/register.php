<?php
require_once __DIR__ . '/../http_client.php';

if ($_SERVER['REQUEST_METHOD']!=='POST'){
  cp_json(405, ['status'=>'error','message'=>'Method not allowed']);
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];

/* Parse Full Name */
$fullName = explode(" ", $input['fullName'] ?? '');
$firstName = $fullName[0] ?? '';
$lastName = isset($fullName[1]) ? implode(" ", array_slice($fullName, 1)) : '';

/* Build payload (adjust static values if needed) */
$payload = [
    'firstName'  => $firstName,
    'lastName'   => $lastName,
    'email'      => $input['email'] ?? '',
    'phone'      => $input['phone'] ?? '',
    'country'    => 'PK',
    'language'   => 'bm',
    'customFields' => '',
    'username'   => $input['email'] ?? null,
    'birthDate'  => $input['birthDate'] ?? null,
    'password'   => $input['password'] ?? '',
    'accounts'   => [[ 'groupName'=>'20900\\STANDART.USD', 'leverage'=>100, 'isDemoAccount'=>false ]],
    'brandId'    => '360e85c5-b81b-474d-87a2-a33fae141eca',
    'businessUnitId' => 'ea8b30a5-57c4-4fe9-8fc1-b9260d9f93c1',
    'isDemoAccount'  => true,
    'tags'       => [[ 'id' => 'bf05cca4-0ac8-4d59-aa1b-e07a5b31c969' ]],
    'notes'      => [[ 'text' => 'ClientPortal-Website' ]],
];

/* Check for missing required fields */
foreach (['firstName', 'lastName', 'email', 'phone', 'password'] as $f) {
    if (empty($payload[$f])) cp_json(400, ['status' => 'error', 'message' => "Missing required: $f"]);
}

/* Pre-auth: NO Authorization header */
$res = cp_call('POST', 'clientzone/leads', $payload, 'none');

if (!$res['ok']) {
    cp_json($res['status'], [
        'status' => 'error',
        'message' => $res['data']['message'] ?? 'Registration failed',
        'details' => $res['data'] ?? null
    ]);
}

cp_json(200, ['status' => 'success', 'data' => $res['data']]);

